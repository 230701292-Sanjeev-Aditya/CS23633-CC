// frontend/tailwind.config.js
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        obsidian:  '#0a0a0f',
        surface:   '#0f0f1a',
        surface2:  '#151522',
        gold:      '#c9a84c',
        'gold-dim':'#6b5420',
        ivory:     '#f0ead8',
        silver:    '#a8b2c4',
        netlify:   '#00ad9f',
        azure:     '#4d8fff',
        docker:    '#2496ed',
        danger:    '#e05260',
        success:   '#3cc962',
      },
      fontFamily: {
        mono: ['"DM Mono"', 'monospace'],
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
      },
    },
  },
  plugins: [],
};
