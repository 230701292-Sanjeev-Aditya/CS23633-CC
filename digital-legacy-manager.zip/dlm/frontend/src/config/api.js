// frontend/src/config/api.js
import axios from 'axios';
import toast  from 'react-hot-toast';

const api = axios.create({
  baseURL:         import.meta.env.VITE_API_URL || '',
  withCredentials: true,          // send HttpOnly cookies
  timeout:         15_000,
});

// ── Request: attach access token if stored ────────────
api.interceptors.request.use(config => {
  const token = sessionStorage.getItem('accessToken');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ── Response: auto-refresh on 401 TOKEN_EXPIRED ───────
let isRefreshing    = false;
let failedQueue     = [];

function processQueue(error, token = null) {
  failedQueue.forEach(({ resolve, reject }) =>
    error ? reject(error) : resolve(token)
  );
  failedQueue = [];
}

api.interceptors.response.use(
  res => res,
  async error => {
    const original = error.config;

    if (
      error.response?.status === 401 &&
      error.response?.data?.code === 'TOKEN_EXPIRED' &&
      !original._retry
    ) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then(token => {
          original.headers.Authorization = `Bearer ${token}`;
          return api(original);
        });
      }

      original._retry  = true;
      isRefreshing      = true;

      try {
        const { data } = await api.post('/api/auth/refresh');
        sessionStorage.setItem('accessToken', data.accessToken);
        processQueue(null, data.accessToken);
        original.headers.Authorization = `Bearer ${data.accessToken}`;
        return api(original);
      } catch (refreshError) {
        processQueue(refreshError, null);
        sessionStorage.removeItem('accessToken');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    // Show toast for non-401 API errors
    if (error.response?.status !== 401) {
      const msg = error.response?.data?.error || 'Something went wrong.';
      toast.error(msg);
    }

    return Promise.reject(error);
  }
);

export default api;
