// frontend/src/store/vaultStore.js
import { create } from 'zustand';
import api from '@/config/api';

export const useVaultStore = create((set, get) => ({
  vaults:        [],
  currentVault:  null,
  assets:        [],
  isLoading:     false,
  error:         null,

  // ── Vaults ──────────────────────────────────────────
  fetchVaults: async () => {
    set({ isLoading: true, error: null });
    try {
      const { data } = await api.get('/api/vaults');
      set({ vaults: data.vaults });
    } catch (err) {
      set({ error: err.message });
    } finally {
      set({ isLoading: false });
    }
  },

  fetchVault: async (id) => {
    set({ isLoading: true });
    try {
      const { data } = await api.get(`/api/vaults/${id}`);
      set({ currentVault: data.vault });
      return data.vault;
    } finally {
      set({ isLoading: false });
    }
  },

  createVault: async (payload) => {
    const { data } = await api.post('/api/vaults', payload);
    set(state => ({ vaults: [data.vault, ...state.vaults] }));
    return data.vault;
  },

  updateVault: async (id, payload) => {
    const { data } = await api.patch(`/api/vaults/${id}`, payload);
    set(state => ({
      vaults: state.vaults.map(v => v._id === id ? data.vault : v),
      currentVault: state.currentVault?._id === id ? data.vault : state.currentVault,
    }));
    return data.vault;
  },

  deleteVault: async (id) => {
    await api.delete(`/api/vaults/${id}`);
    set(state => ({
      vaults:       state.vaults.filter(v => v._id !== id),
      currentVault: state.currentVault?._id === id ? null : state.currentVault,
    }));
  },

  // ── Assets ──────────────────────────────────────────
  fetchAssets: async (vaultId) => {
    set({ isLoading: true });
    try {
      const { data } = await api.get('/api/assets', { params: { vaultId } });
      set({ assets: data.assets });
    } finally {
      set({ isLoading: false });
    }
  },

  uploadAsset: async (formData) => {
    const { data } = await api.post('/api/assets', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    set(state => ({ assets: [data.asset, ...state.assets] }));
    return data.asset;
  },

  downloadAsset: async (assetId) => {
    const { data } = await api.get(`/api/assets/${assetId}/download`);
    return data;
  },

  deleteAsset: async (assetId) => {
    await api.delete(`/api/assets/${assetId}`);
    set(state => ({ assets: state.assets.filter(a => a._id !== assetId) }));
  },
}));
