// frontend/src/store/authStore.js
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import api from '@/config/api';

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user:          null,
      isAuthenticated: false,
      isLoading:     false,

      // ── Local auth ──────────────────────────────────
      login: async (email, password) => {
        set({ isLoading: true });
        try {
          const { data } = await api.post('/api/auth/login', { email, password });
          sessionStorage.setItem('accessToken', data.accessToken);
          set({ user: data.user, isAuthenticated: true });
          return { success: true };
        } catch (err) {
          return { success: false, error: err.response?.data?.error };
        } finally {
          set({ isLoading: false });
        }
      },

      register: async (email, password, displayName) => {
        set({ isLoading: true });
        try {
          const { data } = await api.post('/api/auth/register', { email, password, displayName });
          sessionStorage.setItem('accessToken', data.accessToken);
          set({ user: data.user, isAuthenticated: true });
          return { success: true };
        } catch (err) {
          return { success: false, error: err.response?.data?.error };
        } finally {
          set({ isLoading: false });
        }
      },

      logout: async () => {
        try {
          await api.post('/api/auth/logout');
        } finally {
          sessionStorage.removeItem('accessToken');
          set({ user: null, isAuthenticated: false });
        }
      },

      fetchMe: async () => {
        try {
          const { data } = await api.get('/api/users/me');
          set({ user: data.user, isAuthenticated: true });
        } catch {
          set({ user: null, isAuthenticated: false });
        }
      },

      checkIn: async () => {
        const { data } = await api.post('/api/auth/checkin');
        set(state => ({
          user: { ...state.user, lastCheckIn: data.lastCheckIn },
        }));
        return data;
      },

      updateUser: (updates) => {
        set(state => ({ user: { ...state.user, ...updates } }));
      },
    }),
    {
      name:    'dlm-auth',
      partialize: state => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);
