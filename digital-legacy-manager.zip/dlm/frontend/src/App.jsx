// frontend/src/App.jsx
import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';

// Pages
import LoginPage       from '@/pages/LoginPage';
import RegisterPage    from '@/pages/RegisterPage';
import DashboardPage   from '@/pages/DashboardPage';
import VaultPage       from '@/pages/VaultPage';
import AssetPage       from '@/pages/AssetPage';
import BeneficiariesPage from '@/pages/BeneficiariesPage';
import SettingsPage    from '@/pages/SettingsPage';
import AuditPage       from '@/pages/AuditPage';
import InvitePage      from '@/pages/InvitePage';

// Layout
import AppLayout       from '@/components/layout/AppLayout';
import ProtectedRoute  from '@/components/layout/ProtectedRoute';

export default function App() {
  const { fetchMe, isAuthenticated } = useAuthStore();

  // Rehydrate user on mount
  useEffect(() => {
    if (sessionStorage.getItem('accessToken')) {
      fetchMe();
    }
  }, []);

  return (
    <Routes>
      {/* Public */}
      <Route path="/login"          element={<LoginPage />} />
      <Route path="/register"       element={<RegisterPage />} />
      <Route path="/invite/:token"  element={<InvitePage />} />

      {/* Protected — wrapped in AppLayout */}
      <Route element={<ProtectedRoute />}>
        <Route element={<AppLayout />}>
          <Route index                       element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard"           element={<DashboardPage />} />
          <Route path="/vaults/:id"          element={<VaultPage />} />
          <Route path="/vaults/:id/assets"   element={<AssetPage />} />
          <Route path="/beneficiaries"       element={<BeneficiariesPage />} />
          <Route path="/audit"               element={<AuditPage />} />
          <Route path="/settings"            element={<SettingsPage />} />
        </Route>
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
