// frontend/src/components/layout/AppLayout.jsx
import { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Shield, Users, ScrollText,
  Settings, LogOut, Menu, X, CheckCircle, Bell
} from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';
import { formatDistanceToNow } from 'date-fns';

const NAV = [
  { to: '/dashboard',     icon: LayoutDashboard, label: 'Dashboard'   },
  { to: '/beneficiaries', icon: Users,           label: 'Beneficiaries' },
  { to: '/audit',         icon: ScrollText,      label: 'Audit Log'   },
  { to: '/settings',      icon: Settings,        label: 'Settings'    },
];

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const { user, logout, checkIn } = useAuthStore();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate('/login');
  }

  async function handleCheckIn() {
    try {
      await checkIn();
      toast.success('Check-in recorded. Inactivity timer reset.');
    } catch {
      toast.error('Check-in failed.');
    }
  }

  const lastCheckIn = user?.lastCheckIn
    ? formatDistanceToNow(new Date(user.lastCheckIn), { addSuffix: true })
    : 'Never';

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: 'var(--obsidian)' }}>

      {/* ── Sidebar ────────────────────────────────── */}
      <AnimatePresence initial={false}>
        {sidebarOpen && (
          <motion.aside
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 240, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="flex-shrink-0 flex flex-col overflow-hidden"
            style={{
              background:  'var(--surface)',
              borderRight: '1px solid var(--border)',
            }}
          >
            {/* Logo */}
            <div className="px-6 py-5" style={{ borderBottom: '1px solid var(--border)' }}>
              <div style={{ color: 'var(--gold)', fontSize: 11, letterSpacing: '0.3em', textTransform: 'uppercase' }}>
                ◆ Digital Legacy
              </div>
              <div style={{ color: 'var(--ivory)', fontSize: 18, fontWeight: 600, marginTop: 2 }}>
                Manager
              </div>
            </div>

            {/* Nav links */}
            <nav className="flex-1 px-3 py-4" style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {NAV.map(({ to, icon: Icon, label }) => (
                <NavLink
                  key={to}
                  to={to}
                  style={({ isActive }) => ({
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    padding: '9px 14px',
                    fontSize: 12,
                    letterSpacing: '0.06em',
                    textTransform: 'uppercase',
                    textDecoration: 'none',
                    color:      isActive ? 'var(--gold)'  : 'var(--silver)',
                    background: isActive ? 'rgba(201,168,76,0.08)' : 'transparent',
                    borderLeft: isActive ? '2px solid var(--gold)' : '2px solid transparent',
                    transition: 'all 0.15s',
                  })}
                >
                  <Icon size={15} />
                  {label}
                </NavLink>
              ))}
            </nav>

            {/* Check-in widget */}
            <div className="px-4 py-4" style={{ borderTop: '1px solid var(--border)' }}>
              <div style={{ fontSize: 10, color: 'var(--gold-dim)', letterSpacing: '0.2em', marginBottom: 6 }}>
                LAST CHECK-IN
              </div>
              <div style={{ fontSize: 11, color: 'var(--silver)', marginBottom: 10 }}>
                {lastCheckIn}
              </div>
              <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} onClick={handleCheckIn}>
                <CheckCircle size={13} /> Check In
              </button>
            </div>

            {/* User */}
            <div
              className="px-4 py-4 flex items-center gap-3 cursor-pointer"
              style={{ borderTop: '1px solid var(--border)' }}
              onClick={handleLogout}
            >
              <div
                style={{
                  width: 32, height: 32, borderRadius: '50%',
                  background: 'var(--gold)', display: 'flex',
                  alignItems: 'center', justifyContent: 'center',
                  fontSize: 13, color: 'var(--obsidian)', fontWeight: 600, flexShrink: 0,
                }}
              >
                {user?.displayName?.[0]?.toUpperCase() || 'U'}
              </div>
              <div style={{ flex: 1, overflow: 'hidden' }}>
                <div style={{ fontSize: 12, color: 'var(--ivory)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {user?.displayName}
                </div>
                <div style={{ fontSize: 10, color: 'var(--gold-dim)' }}>Logout</div>
              </div>
              <LogOut size={13} style={{ color: 'var(--gold-dim)', flexShrink: 0 }} />
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* ── Main ───────────────────────────────────── */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Topbar */}
        <header
          style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '0 24px', height: 56,
            borderBottom: '1px solid var(--border)',
            background: 'var(--surface)', flexShrink: 0,
          }}
        >
          <button
            onClick={() => setSidebarOpen(v => !v)}
            style={{ background: 'none', border: 'none', color: 'var(--silver)', cursor: 'pointer', padding: 4 }}
          >
            {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
          <Shield size={15} style={{ color: 'var(--gold)' }} />
          <span style={{ fontSize: 11, color: 'var(--gold)', letterSpacing: '0.25em', textTransform: 'uppercase' }}>
            Secure Vault
          </span>
          <div style={{ flex: 1 }} />
          <Bell size={16} style={{ color: 'var(--silver)', cursor: 'pointer' }} />
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto" style={{ padding: 28 }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
