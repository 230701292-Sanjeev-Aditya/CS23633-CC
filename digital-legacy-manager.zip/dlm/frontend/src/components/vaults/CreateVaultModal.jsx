// frontend/src/components/vaults/CreateVaultModal.jsx
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Shield } from 'lucide-react';
import { useVaultStore } from '@/store/vaultStore';
import toast from 'react-hot-toast';

const TRIGGER_TYPES = [
  { value: 'inactivity', label: 'Inactivity',  desc: 'Release if I stop checking in' },
  { value: 'time_lock',  label: 'Time Lock',   desc: 'Release on a specific date'     },
  { value: 'manual',     label: 'Manual',      desc: 'I control when to release'       },
  { value: 'legal',      label: 'Legal',       desc: 'Requires legal confirmation'     },
];

export default function CreateVaultModal({ onClose }) {
  const [name,           setName]           = useState('');
  const [description,    setDescription]    = useState('');
  const [triggerType,    setTriggerType]    = useState('inactivity');
  const [inactivityDays, setInactivityDays] = useState(60);
  const [releaseAt,      setReleaseAt]      = useState('');
  const [loading,        setLoading]        = useState(false);

  const { createVault } = useVaultStore();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const trigger = { type: triggerType };
      if (triggerType === 'inactivity') trigger.inactivityDays = Number(inactivityDays);
      if (triggerType === 'time_lock')  trigger.releaseAt = new Date(releaseAt).toISOString();

      await createVault({ name, description, trigger });
      toast.success('Vault created successfully.');
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to create vault.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        style={{
          position: 'fixed', inset: 0, zIndex: 100,
          background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20,
        }}
        onClick={e => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96 }}
          style={{
            background: 'var(--surface)', border: '1px solid var(--border-bright)',
            width: '100%', maxWidth: 480, padding: 32,
          }}
        >
          {/* Header */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Shield size={18} style={{ color: 'var(--gold)' }} />
              <span style={{ fontSize: 14, color: 'var(--ivory)', letterSpacing: '0.06em' }}>
                CREATE NEW VAULT
              </span>
            </div>
            <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--silver)', cursor: 'pointer' }}>
              <X size={18} />
            </button>
          </div>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            {/* Name */}
            <div>
              <label style={{ display: 'block', fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 6 }}>
                VAULT NAME *
              </label>
              <input
                className="input"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Personal Documents"
                required
                maxLength={100}
              />
            </div>

            {/* Description */}
            <div>
              <label style={{ display: 'block', fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 6 }}>
                DESCRIPTION
              </label>
              <textarea
                className="input"
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="What does this vault contain?"
                rows={2}
                maxLength={500}
                style={{ resize: 'vertical' }}
              />
            </div>

            {/* Trigger type */}
            <div>
              <label style={{ display: 'block', fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 8 }}>
                RELEASE TRIGGER *
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                {TRIGGER_TYPES.map(t => (
                  <div
                    key={t.value}
                    onClick={() => setTriggerType(t.value)}
                    style={{
                      padding: '10px 12px', cursor: 'pointer',
                      border: `1px solid ${triggerType === t.value ? 'var(--gold)' : 'var(--border)'}`,
                      background: triggerType === t.value ? 'rgba(201,168,76,0.08)' : 'transparent',
                      transition: 'all 0.15s',
                    }}
                  >
                    <div style={{ fontSize: 11, color: triggerType === t.value ? 'var(--gold)' : 'var(--ivory)', marginBottom: 2 }}>
                      {t.label}
                    </div>
                    <div style={{ fontSize: 10, color: 'var(--silver)' }}>{t.desc}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Trigger config */}
            {triggerType === 'inactivity' && (
              <div>
                <label style={{ display: 'block', fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 6 }}>
                  DAYS OF INACTIVITY BEFORE RELEASE
                </label>
                <input
                  className="input"
                  type="number"
                  min={7} max={365}
                  value={inactivityDays}
                  onChange={e => setInactivityDays(e.target.value)}
                />
                <div style={{ fontSize: 10, color: 'var(--silver)', marginTop: 4 }}>
                  Warning email sent {Math.max(inactivityDays - 30, 7)} days before release.
                </div>
              </div>
            )}

            {triggerType === 'time_lock' && (
              <div>
                <label style={{ display: 'block', fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 6 }}>
                  RELEASE DATE & TIME
                </label>
                <input
                  className="input"
                  type="datetime-local"
                  value={releaseAt}
                  onChange={e => setReleaseAt(e.target.value)}
                  required
                  min={new Date(Date.now() + 86400000).toISOString().slice(0, 16)}
                />
              </div>
            )}

            {/* Actions */}
            <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
              <button type="button" className="btn btn-ghost" onClick={onClose} style={{ flex: 1, justifyContent: 'center' }}>
                Cancel
              </button>
              <button type="submit" className="btn btn-primary" disabled={loading} style={{ flex: 1, justifyContent: 'center' }}>
                {loading ? 'Creating…' : 'Create Vault'}
              </button>
            </div>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
