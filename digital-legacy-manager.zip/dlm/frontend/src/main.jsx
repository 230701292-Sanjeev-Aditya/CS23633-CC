// frontend/src/main.jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { MsalProvider } from '@azure/msal-react';
import { Toaster } from 'react-hot-toast';
import { msalInstance } from '@/config/msalConfig';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MsalProvider instance={msalInstance}>
      <BrowserRouter>
        <App />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#1a1a2e',
              color: '#e8e8f0',
              border: '1px solid rgba(201,168,76,0.3)',
              fontFamily: 'monospace',
              fontSize: '13px',
            },
            success: { iconTheme: { primary: '#c9a84c', secondary: '#1a1a2e' } },
            error:   { iconTheme: { primary: '#e05260', secondary: '#1a1a2e' } },
          }}
        />
      </BrowserRouter>
    </MsalProvider>
  </React.StrictMode>
);
