// frontend/src/pages/BeneficiariesPage.jsx
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Plus, Trash2, Mail, UserCheck, UserX, Shield } from 'lucide-react';
import api from '@/config/api';
import { useVaultStore } from '@/store/vaultStore';
import toast from 'react-hot-toast';
import { formatDistanceToNow } from 'date-fns';

const STATUS_STYLE = {
  pending:  { color: 'var(--gold)',    icon: <Mail       size={12} /> },
  accepted: { color: 'var(--success)', icon: <UserCheck  size={12} /> },
  declined: { color: 'var(--danger)',  icon: <UserX      size={12} /> },
};

export default function BeneficiariesPage() {
  const [beneficiaries, setBeneficiaries] = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [showForm,      setShowForm]      = useState(false);
  const { vaults, fetchVaults } = useVaultStore();

  const [form, setForm] = useState({ email: '', name: '', vaultId: '', role: 'viewer', relation: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchVaults();
    loadBeneficiaries();
  }, []);

  async function loadBeneficiaries() {
    setLoading(true);
    try {
      const { data } = await api.get('/api/beneficiaries');
      setBeneficiaries(data.beneficiaries);
    } finally {
      setLoading(false);
    }
  }

  async function handleInvite(e) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const { data } = await api.post('/api/beneficiaries', form);
      setBeneficiaries(prev => [data.beneficiary, ...prev]);
      setForm({ email: '', name: '', vaultId: '', role: 'viewer', relation: '' });
      setShowForm(false);
      toast.success('Invitation sent.');
    } catch {
      toast.error('Failed to send invitation.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleRemove(id) {
    if (!window.confirm('Remove this beneficiary?')) return;
    await api.delete(`/api/beneficiaries/${id}`);
    setBeneficiaries(prev => prev.filter(b => b._id !== id));
    toast.success('Beneficiary removed.');
  }

  const vaultName = id => vaults.find(v => v._id === id)?.name || id;

  return (
    <div style={{ maxWidth: 860, margin: '0 auto' }}>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 }}>
        <div>
          <div style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.3em', marginBottom: 4 }}>MANAGE</div>
          <h1 style={{ fontSize: 22, color: 'var(--ivory)', margin: 0 }}>Beneficiaries</h1>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm(v => !v)}>
          <Plus size={14} /> Invite Beneficiary
        </button>
      </div>

      {/* Invite form */}
      {showForm && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="card"
          style={{ marginBottom: 24, padding: 24 }}
        >
          <div style={{ fontSize: 11, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 18 }}>
            NEW BENEFICIARY INVITATION
          </div>
          <form onSubmit={handleInvite}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
              <div>
                <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.15em', display: 'block', marginBottom: 4 }}>FULL NAME *</label>
                <input className="input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
              </div>
              <div>
                <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.15em', display: 'block', marginBottom: 4 }}>EMAIL *</label>
                <input className="input" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required />
              </div>
              <div>
                <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.15em', display: 'block', marginBottom: 4 }}>VAULT *</label>
                <select className="input" value={form.vaultId} onChange={e => setForm(f => ({ ...f, vaultId: e.target.value }))} required style={{ appearance: 'none' }}>
                  <option value="">Select vault…</option>
                  {vaults.filter(v => v.status === 'active').map(v => (
                    <option key={v._id} value={v._id} style={{ background: 'var(--surface2)' }}>{v.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.15em', display: 'block', marginBottom: 4 }}>ROLE *</label>
                <select className="input" value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))} style={{ appearance: 'none' }}>
                  <option value="executor" style={{ background: 'var(--surface2)' }}>Executor (full access)</option>
                  <option value="viewer"   style={{ background: 'var(--surface2)' }}>Viewer (read-only)</option>
                  <option value="partial"  style={{ background: 'var(--surface2)' }}>Partial (specific assets)</option>
                </select>
              </div>
              <div>
                <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.15em', display: 'block', marginBottom: 4 }}>RELATION</label>
                <input className="input" value={form.relation} onChange={e => setForm(f => ({ ...f, relation: e.target.value }))} placeholder="e.g. spouse, child, lawyer" />
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button type="button" className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={submitting}>
                {submitting ? 'Sending…' : <><Mail size={13} /> Send Invitation</>}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* List */}
      {loading ? (
        <div style={{ color: 'var(--silver)', fontSize: 12, padding: 24 }}>Loading…</div>
      ) : beneficiaries.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: 48 }}>
          <Users size={32} style={{ color: 'var(--gold-dim)', margin: '0 auto 14px' }} />
          <div style={{ color: 'var(--silver)', fontSize: 13 }}>No beneficiaries added yet.</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {beneficiaries.map((b, i) => (
            <motion.div
              key={b._id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.04 }}
              className="card"
              style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 16 }}
            >
              <div style={{
                width: 38, height: 38, borderRadius: '50%', flexShrink: 0,
                background: 'rgba(201,168,76,0.1)', border: '1px solid var(--border)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 14, color: 'var(--gold)', fontWeight: 600,
              }}>
                {b.name[0].toUpperCase()}
              </div>

              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                  <span style={{ fontSize: 13, color: 'var(--ivory)', fontWeight: 500 }}>{b.name}</span>
                  {b.relation && <span style={{ fontSize: 10, color: 'var(--silver)' }}>· {b.relation}</span>}
                  <span style={{ fontSize: 10, color: STATUS_STYLE[b.inviteStatus]?.color, display: 'flex', alignItems: 'center', gap: 4 }}>
                    {STATUS_STYLE[b.inviteStatus]?.icon} {b.inviteStatus}
                  </span>
                </div>
                <div style={{ fontSize: 11, color: 'var(--silver)' }}>
                  {b.email} · <span style={{ textTransform: 'uppercase' }}>{b.role}</span> ·{' '}
                  Vault: <span style={{ color: 'var(--gold-dim)' }}>{vaultName(b.vault)}</span> ·{' '}
                  Added {formatDistanceToNow(new Date(b.createdAt), { addSuffix: true })}
                </div>
              </div>

              <div style={{ display: 'flex', gap: 6, flexShrink: 0, alignItems: 'center' }}>
                <div style={{ padding: '3px 10px', border: '1px solid var(--border)', fontSize: 10,
                              color: 'var(--silver)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  <Shield size={10} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 4 }} />
                  {b.role}
                </div>
                <button
                  onClick={() => handleRemove(b._id)}
                  style={{ background: 'none', border: '1px solid rgba(224,82,96,0.3)', color: 'var(--danger)',
                           padding: '5px 8px', cursor: 'pointer' }}
                >
                  <Trash2 size={13} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
