// frontend/src/pages/InvitePage.jsx
import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, CheckCircle, XCircle, Loader } from 'lucide-react';
import api from '@/config/api';

export default function InvitePage() {
  const { token } = useParams();
  const [status, setStatus] = useState('loading'); // loading | success | error
  const [beneficiary, setBeneficiary] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    async function accept() {
      try {
        const { data } = await api.post(`/api/beneficiaries/accept/${token}`);
        setBeneficiary(data.beneficiary);
        setStatus('success');
      } catch (err) {
        setError(err.response?.data?.error || 'This invitation link is invalid or has expired.');
        setStatus('error');
      }
    }
    accept();
  }, [token]);

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: 'var(--obsidian)', padding: 20 }}>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                  style={{ maxWidth: 440, width: '100%', textAlign: 'center' }}>
        <div style={{ marginBottom: 24 }}>
          <Shield size={48} style={{ color: 'var(--gold)', margin: '0 auto 16px' }} />
          <h1 style={{ fontSize: 20, color: 'var(--ivory)', margin: '0 0 8px', fontFamily: 'monospace' }}>
            Digital Legacy Manager
          </h1>
          <p style={{ fontSize: 12, color: 'var(--silver)', letterSpacing: '0.1em' }}>BENEFICIARY INVITATION</p>
        </div>

        <div className="card" style={{ padding: 36 }}>
          {status === 'loading' && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
              <Loader size={28} style={{ color: 'var(--gold)', animation: 'spin 1s linear infinite' }} />
              <p style={{ color: 'var(--silver)', fontSize: 13 }}>Processing your invitation…</p>
            </div>
          )}

          {status === 'success' && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
              <CheckCircle size={40} style={{ color: 'var(--success)' }} />
              <h2 style={{ fontSize: 18, color: 'var(--ivory)', margin: 0 }}>Invitation Accepted</h2>
              <p style={{ color: 'var(--silver)', fontSize: 13, lineHeight: 1.6 }}>
                Hello <strong style={{ color: 'var(--ivory)' }}>{beneficiary?.name}</strong>,
                you have been added as a beneficiary with{' '}
                <strong style={{ color: 'var(--gold)' }}>{beneficiary?.role}</strong> access.
                You will be notified when the vault is released.
              </p>
              <div style={{ padding: '10px 16px', border: '1px solid var(--border)', fontSize: 11,
                            color: 'var(--silver)', width: '100%', marginTop: 8 }}>
                <div style={{ color: 'var(--gold-dim)', fontSize: 10, letterSpacing: '0.2em', marginBottom: 4 }}>ROLE</div>
                <span style={{ textTransform: 'uppercase', color: 'var(--gold)' }}>{beneficiary?.role}</span>
              </div>
              <Link to="/login" style={{ color: 'var(--gold)', fontSize: 12, marginTop: 4, textDecoration: 'none' }}>
                Sign in to your own account →
              </Link>
            </div>
          )}

          {status === 'error' && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
              <XCircle size={40} style={{ color: 'var(--danger)' }} />
              <h2 style={{ fontSize: 18, color: 'var(--ivory)', margin: 0 }}>Invitation Invalid</h2>
              <p style={{ color: 'var(--silver)', fontSize: 13 }}>{error}</p>
            </div>
          )}
        </div>
      </motion.div>

      <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
