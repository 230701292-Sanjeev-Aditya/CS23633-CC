// frontend/src/pages/RegisterPage.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, Eye, EyeOff, CheckCircle, XCircle } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

function PasswordRule({ met, text }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11,
                  color: met ? 'var(--success)' : 'var(--silver)' }}>
      {met ? <CheckCircle size={11} /> : <XCircle size={11} />}
      {text}
    </div>
  );
}

export default function RegisterPage() {
  const [displayName, setDisplayName] = useState('');
  const [email,       setEmail]       = useState('');
  const [password,    setPassword]    = useState('');
  const [showPw,      setShowPw]      = useState(false);
  const [loading,     setLoading]     = useState(false);

  const { register } = useAuthStore();
  const navigate = useNavigate();

  const rules = {
    length:  password.length >= 12,
    upper:   /[A-Z]/.test(password),
    lower:   /[a-z]/.test(password),
    digit:   /\d/.test(password),
    special: /[@$!%*?&]/.test(password),
  };
  const isStrong = Object.values(rules).every(Boolean);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!isStrong) { toast.error('Password does not meet requirements.'); return; }
    setLoading(true);
    const result = await register(email, password, displayName);
    setLoading(false);
    if (result.success) { toast.success('Account created.'); navigate('/dashboard'); }
    else toast.error(result.error || 'Registration failed.');
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: 'var(--obsidian)', padding: 20 }}>
      <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none',
                    backgroundImage: 'linear-gradient(rgba(201,168,76,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(201,168,76,0.03) 1px, transparent 1px)',
                    backgroundSize: '48px 48px' }} />

      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
                  style={{ width: '100%', maxWidth: 420, position: 'relative', zIndex: 1 }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{ width: 52, height: 52, background: 'rgba(201,168,76,0.1)',
                        border: '1px solid var(--border-bright)',
                        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: 14 }}>
            <Shield size={24} style={{ color: 'var(--gold)' }} />
          </div>
          <h1 style={{ fontSize: 22, color: 'var(--ivory)', margin: '0 0 6px', fontFamily: 'monospace' }}>Create Account</h1>
          <p style={{ fontSize: 12, color: 'var(--silver)', letterSpacing: '0.1em' }}>DIGITAL LEGACY MANAGER</p>
        </div>

        <div className="card" style={{ padding: 32 }}>
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', display: 'block', marginBottom: 6 }}>DISPLAY NAME *</label>
              <input className="input" value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Your full name" required />
            </div>
            <div>
              <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', display: 'block', marginBottom: 6 }}>EMAIL *</label>
              <input className="input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" required autoComplete="email" />
            </div>
            <div>
              <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', display: 'block', marginBottom: 6 }}>PASSWORD *</label>
              <div style={{ position: 'relative' }}>
                <input className="input" type={showPw ? 'text' : 'password'} value={password}
                       onChange={e => setPassword(e.target.value)} placeholder="12+ characters" required style={{ paddingRight: 44 }} />
                <button type="button" onClick={() => setShowPw(v => !v)}
                        style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
                                 background: 'none', border: 'none', color: 'var(--silver)', cursor: 'pointer' }}>
                  {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
              {password && (
                <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 3 }}>
                  <PasswordRule met={rules.length}  text="At least 12 characters" />
                  <PasswordRule met={rules.upper}   text="Uppercase letter" />
                  <PasswordRule met={rules.lower}   text="Lowercase letter" />
                  <PasswordRule met={rules.digit}   text="Number" />
                  <PasswordRule met={rules.special} text="Special character (@$!%*?&)" />
                </div>
              )}
            </div>
            <button className="btn btn-primary" type="submit" disabled={loading || !isStrong}
                    style={{ width: '100%', justifyContent: 'center', marginTop: 6, opacity: (!isStrong && password) ? 0.5 : 1 }}>
              {loading ? 'Creating account…' : 'Create Account'}
            </button>
          </form>
        </div>

        <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--silver)', marginTop: 20 }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color: 'var(--gold)', textDecoration: 'none' }}>Sign in</Link>
        </p>
      </motion.div>
    </div>
  );
}
