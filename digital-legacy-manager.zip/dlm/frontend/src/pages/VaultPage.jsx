// frontend/src/pages/VaultPage.jsx
import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { motion } from 'framer-motion';
import {
  Upload, File, Image, Video, Key, Wallet, MessageSquare,
  Landmark, Package, Trash2, Download, ArrowLeft, ChevronDown
} from 'lucide-react';
import { useVaultStore } from '@/store/vaultStore';
import toast from 'react-hot-toast';
import { formatDistanceToNow } from 'date-fns';

const TYPE_ICON = {
  document:       <File      size={16} style={{ color: 'var(--azure)'   }} />,
  photo:          <Image     size={16} style={{ color: 'var(--netlify)' }} />,
  video:          <Video     size={16} style={{ color: '#a78bfa'        }} />,
  password:       <Key       size={16} style={{ color: 'var(--gold)'    }} />,
  crypto_wallet:  <Wallet    size={16} style={{ color: 'var(--gold)'    }} />,
  message:        <MessageSquare size={16} style={{ color: 'var(--success)' }} />,
  financial:      <Landmark  size={16} style={{ color: '#fb923c'        }} />,
  social_account: <Package   size={16} style={{ color: '#f472b6'        }} />,
  other:          <Package   size={16} style={{ color: 'var(--silver)'  }} />,
};

const ASSET_TYPES = ['document','photo','video','password','crypto_wallet','message','financial','social_account','other'];

function formatBytes(b) {
  if (!b) return '—';
  const k = 1024, sizes = ['B','KB','MB','GB'];
  const i = Math.floor(Math.log(b) / Math.log(k));
  return `${parseFloat((b/Math.pow(k,i)).toFixed(1))} ${sizes[i]}`;
}

export default function VaultPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currentVault, assets, fetchVault, fetchAssets, uploadAsset, downloadAsset, deleteAsset, isLoading } = useVaultStore();

  const [uploading,  setUploading]  = useState(false);
  const [assetName,  setAssetName]  = useState('');
  const [assetType,  setAssetType]  = useState('document');
  const [pendingFile, setPendingFile] = useState(null);
  const [filterType, setFilterType] = useState('all');

  useEffect(() => {
    fetchVault(id);
    fetchAssets(id);
  }, [id]);

  const onDrop = useCallback(files => {
    if (files[0]) {
      setPendingFile(files[0]);
      setAssetName(files[0].name.replace(/\.[^/.]+$/, ''));
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    maxSize: 100 * 1024 * 1024,
    multiple: false,
  });

  async function handleUpload(e) {
    e.preventDefault();
    if (!pendingFile && !assetName) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('vaultId', id);
      fd.append('name', assetName);
      fd.append('type', assetType);
      if (pendingFile) fd.append('file', pendingFile);
      await uploadAsset(fd);
      toast.success('Asset uploaded.');
      setPendingFile(null);
      setAssetName('');
    } catch {
      toast.error('Upload failed.');
    } finally {
      setUploading(false);
    }
  }

  async function handleDownload(asset) {
    try {
      const result = await downloadAsset(asset._id);
      if (result.downloadUrl) {
        window.open(result.downloadUrl, '_blank');
      }
    } catch { toast.error('Download failed.'); }
  }

  async function handleDelete(assetId) {
    if (!window.confirm('Delete this asset permanently?')) return;
    await deleteAsset(assetId);
    toast.success('Asset deleted.');
  }

  const filtered = filterType === 'all' ? assets : assets.filter(a => a.type === filterType);

  return (
    <div style={{ maxWidth: 1000, margin: '0 auto' }}>
      {/* Breadcrumb */}
      <button
        onClick={() => navigate('/dashboard')}
        style={{ background: 'none', border: 'none', color: 'var(--silver)', cursor: 'pointer',
                 display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, marginBottom: 20, padding: 0 }}
      >
        <ArrowLeft size={14} /> Back to Dashboard
      </button>

      {/* Vault header */}
      {currentVault && (
        <div style={{ marginBottom: 28 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <h1 style={{ fontSize: 22, color: 'var(--ivory)', margin: 0 }}>{currentVault.name}</h1>
            <span className={`badge badge-${currentVault.status}`}>{currentVault.status}</span>
          </div>
          {currentVault.description && (
            <p style={{ fontSize: 13, color: 'var(--silver)', margin: 0 }}>{currentVault.description}</p>
          )}
          <div style={{ fontSize: 11, color: 'var(--gold-dim)', marginTop: 6 }}>
            {currentVault.assetCount || 0} assets · {formatBytes(currentVault.totalSizeBytes)} ·
            Trigger: {currentVault.trigger?.type}
          </div>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 20, alignItems: 'start' }}>

        {/* Asset list */}
        <div>
          {/* Filter bar */}
          <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap' }}>
            {['all', ...ASSET_TYPES].map(t => (
              <button
                key={t}
                onClick={() => setFilterType(t)}
                style={{
                  fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase',
                  padding: '4px 12px', cursor: 'pointer',
                  border: `1px solid ${filterType === t ? 'var(--gold)' : 'var(--border)'}`,
                  color:   filterType === t ? 'var(--gold)' : 'var(--silver)',
                  background: filterType === t ? 'rgba(201,168,76,0.08)' : 'transparent',
                }}
              >
                {t.replace('_', ' ')}
              </button>
            ))}
          </div>

          {isLoading && <div style={{ color: 'var(--silver)', fontSize: 12, padding: 24 }}>Loading assets…</div>}

          {!isLoading && filtered.length === 0 && (
            <div className="card" style={{ textAlign: 'center', padding: 40 }}>
              <Package size={28} style={{ color: 'var(--gold-dim)', margin: '0 auto 12px' }} />
              <div style={{ color: 'var(--silver)', fontSize: 13 }}>
                No assets {filterType !== 'all' ? `of type "${filterType}"` : 'in this vault'} yet.
              </div>
            </div>
          )}

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {filtered.map((asset, i) => (
              <motion.div
                key={asset._id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className="card"
                style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14 }}
              >
                <div style={{
                  width: 34, height: 34, flexShrink: 0,
                  background: 'rgba(201,168,76,0.06)', border: '1px solid var(--border)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {TYPE_ICON[asset.type] || TYPE_ICON.other}
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, color: 'var(--ivory)', marginBottom: 2,
                                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {asset.name}
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--silver)' }}>
                    {asset.type.replace('_', ' ')} · {formatBytes(asset.sizeBytes)} ·{' '}
                    {formatDistanceToNow(new Date(asset.createdAt), { addSuffix: true })}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                  {asset.blobName && (
                    <button
                      onClick={() => handleDownload(asset)}
                      style={{ background: 'none', border: '1px solid var(--border)', color: 'var(--silver)',
                               padding: '5px 8px', cursor: 'pointer' }}
                      title="Download"
                    >
                      <Download size={13} />
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(asset._id)}
                    style={{ background: 'none', border: '1px solid rgba(224,82,96,0.3)', color: 'var(--danger)',
                             padding: '5px 8px', cursor: 'pointer' }}
                    title="Delete"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Upload panel */}
        <div className="card" style={{ padding: 20, position: 'sticky', top: 0 }}>
          <div style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.25em', marginBottom: 16 }}>
            UPLOAD ASSET
          </div>

          {/* Dropzone */}
          <div
            {...getRootProps()}
            style={{
              border: `2px dashed ${isDragActive ? 'var(--gold)' : 'var(--border)'}`,
              padding: '24px 16px', textAlign: 'center', cursor: 'pointer',
              background: isDragActive ? 'rgba(201,168,76,0.05)' : 'transparent',
              transition: 'all 0.2s', marginBottom: 14,
            }}
          >
            <input {...getInputProps()} />
            <Upload size={22} style={{ color: 'var(--gold-dim)', margin: '0 auto 8px' }} />
            {pendingFile ? (
              <div style={{ fontSize: 11, color: 'var(--success)' }}>{pendingFile.name}</div>
            ) : (
              <div style={{ fontSize: 11, color: 'var(--silver)' }}>
                {isDragActive ? 'Drop file here' : 'Drag & drop or click to browse'}
                <br /><span style={{ color: 'var(--gold-dim)' }}>Max 100MB</span>
              </div>
            )}
          </div>

          <form onSubmit={handleUpload} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div>
              <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.15em', display: 'block', marginBottom: 4 }}>
                ASSET NAME *
              </label>
              <input className="input" value={assetName} onChange={e => setAssetName(e.target.value)}
                     placeholder="Descriptive name" required />
            </div>

            <div>
              <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.15em', display: 'block', marginBottom: 4 }}>
                TYPE *
              </label>
              <select
                className="input"
                value={assetType}
                onChange={e => setAssetType(e.target.value)}
                style={{ appearance: 'none', cursor: 'pointer' }}
              >
                {ASSET_TYPES.map(t => (
                  <option key={t} value={t} style={{ background: 'var(--surface2)' }}>
                    {t.replace('_', ' ').replace(/^\w/, c => c.toUpperCase())}
                  </option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              disabled={uploading || (!pendingFile && !assetName)}
              style={{ width: '100%', justifyContent: 'center', marginTop: 4 }}
            >
              {uploading ? 'Uploading…' : <><Upload size={13} /> Upload Asset</>}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
