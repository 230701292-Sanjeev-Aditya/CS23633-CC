// frontend/src/pages/SettingsPage.jsx
import { useState } from 'react';
import { useAuthStore } from '@/store/authStore';
import { Shield, Trash2, Key, Bell } from 'lucide-react';
import api from '@/config/api';
import toast from 'react-hot-toast';

export default function SettingsPage() {
  const { user, logout, updateUser } = useAuthStore();
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [saving, setSaving] = useState(false);

  async function saveProfile(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const { data } = await api.patch('/api/users/me', { displayName });
      updateUser(data.user);
      toast.success('Profile updated.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDeleteAccount() {
    if (!window.confirm('This will permanently delete your account and anonymise all data. Are you sure?')) return;
    if (!window.confirm('FINAL CONFIRMATION: Delete account?')) return;
    try {
      await api.delete('/api/users/me');
      await logout();
      window.location.href = '/login';
    } catch { toast.error('Delete failed.'); }
  }

  return (
    <div style={{ maxWidth: 600, margin: '0 auto' }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.3em', marginBottom: 4 }}>ACCOUNT</div>
        <h1 style={{ fontSize: 22, color: 'var(--ivory)', margin: 0 }}>Settings</h1>
      </div>

      {/* Profile */}
      <div className="card" style={{ marginBottom: 16, padding: 24 }}>
        <div style={{ fontSize: 11, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 16 }}>PROFILE</div>
        <form onSubmit={saveProfile} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.15em', display: 'block', marginBottom: 4 }}>DISPLAY NAME</label>
            <input className="input" value={displayName} onChange={e => setDisplayName(e.target.value)} />
          </div>
          <div>
            <label style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.15em', display: 'block', marginBottom: 4 }}>EMAIL</label>
            <input className="input" value={user?.email} disabled style={{ opacity: 0.5, cursor: 'not-allowed' }} />
          </div>
          <button type="submit" className="btn btn-primary" disabled={saving} style={{ alignSelf: 'flex-start' }}>
            {saving ? 'Saving…' : 'Save Changes'}
          </button>
        </form>
      </div>

      {/* Security */}
      <div className="card" style={{ marginBottom: 16, padding: 24 }}>
        <div style={{ fontSize: 11, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 16 }}>
          <Shield size={12} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 6 }} />
          SECURITY
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                        padding: '12px 16px', border: '1px solid var(--border)' }}>
            <div>
              <div style={{ fontSize: 13, color: 'var(--ivory)', marginBottom: 2 }}>Two-Factor Authentication</div>
              <div style={{ fontSize: 11, color: 'var(--silver)' }}>TOTP via authenticator app</div>
            </div>
            <span className={`badge ${user?.mfaEnabled ? 'badge-active' : 'badge-pending'}`}>
              {user?.mfaEnabled ? 'Enabled' : 'Disabled'}
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                        padding: '12px 16px', border: '1px solid var(--border)' }}>
            <div>
              <div style={{ fontSize: 13, color: 'var(--ivory)', marginBottom: 2 }}>Azure AD Login</div>
              <div style={{ fontSize: 11, color: 'var(--silver)' }}>Microsoft identity provider</div>
            </div>
            <span className={`badge ${user?.provider === 'azure_ad' ? 'badge-active' : 'badge-archived'}`}>
              {user?.provider === 'azure_ad' ? 'Connected' : 'Not connected'}
            </span>
          </div>
        </div>
      </div>

      {/* Danger zone */}
      <div className="card" style={{ padding: 24, borderColor: 'rgba(224,82,96,0.3)' }}>
        <div style={{ fontSize: 11, color: 'var(--danger)', letterSpacing: '0.2em', marginBottom: 16 }}>
          DANGER ZONE
        </div>
        <div style={{ fontSize: 13, color: 'var(--silver)', marginBottom: 16, lineHeight: 1.6 }}>
          Deleting your account will permanently anonymise all personal data (GDPR right to erasure).
          Your vaults will be archived.
        </div>
        <button className="btn btn-danger" onClick={handleDeleteAccount}>
          <Trash2 size={13} /> Delete My Account
        </button>
      </div>
    </div>
  );
}
