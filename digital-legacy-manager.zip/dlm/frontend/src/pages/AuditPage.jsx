// frontend/src/pages/AuditPage.jsx
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ScrollText, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import api from '@/config/api';

const ACTION_COLORS = {
  login:             'var(--success)',
  logout:            'var(--silver)',
  register:          'var(--azure)',
  vault_create:      'var(--gold)',
  vault_update:      'var(--gold-dim)',
  vault_delete:      'var(--danger)',
  asset_upload:      'var(--netlify)',
  asset_view:        'var(--silver)',
  asset_delete:      'var(--danger)',
  beneficiary_invite:'var(--azure)',
  vault_release:     '#f97316',
  checkin:           'var(--success)',
  export_inventory:  'var(--silver)',
};

export default function AuditPage() {
  const [logs,    setLogs]    = useState([]);
  const [loading, setLoading] = useState(true);
  const [page,    setPage]    = useState(1);

  useEffect(() => { loadLogs(); }, [page]);

  async function loadLogs() {
    setLoading(true);
    try {
      const { data } = await api.get('/api/users/me/audit', { params: { page, limit: 50 } });
      setLogs(data.logs);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 860, margin: '0 auto' }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.3em', marginBottom: 4 }}>SECURITY</div>
        <h1 style={{ fontSize: 22, color: 'var(--ivory)', margin: 0 }}>Audit Log</h1>
        <p style={{ fontSize: 12, color: 'var(--silver)', margin: '6px 0 0', fontStyle: 'italic' }}>
          Immutable record of all actions on your account and vaults.
        </p>
      </div>

      {loading ? (
        <div style={{ color: 'var(--silver)', fontSize: 12, padding: 24 }}>Loading audit trail…</div>
      ) : logs.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: 48 }}>
          <ScrollText size={28} style={{ color: 'var(--gold-dim)', margin: '0 auto 12px' }} />
          <div style={{ color: 'var(--silver)', fontSize: 13 }}>No audit events yet.</div>
        </div>
      ) : (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {/* Table header */}
          <div style={{
            display: 'grid', gridTemplateColumns: '160px 1fr 160px 60px',
            padding: '10px 20px', borderBottom: '1px solid var(--border)',
            fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em',
          }}>
            <span>TIMESTAMP</span>
            <span>ACTION</span>
            <span>RESOURCE</span>
            <span>STATUS</span>
          </div>

          {logs.map((log, i) => (
            <motion.div
              key={log._id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: i * 0.015 }}
              style={{
                display: 'grid', gridTemplateColumns: '160px 1fr 160px 60px',
                padding: '12px 20px',
                borderBottom: i < logs.length - 1 ? '1px solid rgba(201,168,76,0.06)' : 'none',
                fontSize: 12,
              }}
            >
              <span style={{ color: 'var(--silver)', fontSize: 11, fontFamily: 'monospace' }}>
                {format(new Date(log.createdAt), 'MMM d HH:mm:ss')}
              </span>
              <div>
                <span style={{
                  color: ACTION_COLORS[log.action] || 'var(--ivory)',
                  fontSize: 12, fontFamily: 'monospace',
                }}>
                  {log.action.replace(/_/g, ' ')}
                </span>
                {log.ip && (
                  <span style={{ fontSize: 10, color: 'var(--gold-dim)', marginLeft: 10 }}>
                    {log.ip}
                  </span>
                )}
              </div>
              <span style={{ color: 'var(--silver)', fontSize: 11, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {log.resource || '—'}
              </span>
              <span>
                {log.success
                  ? <CheckCircle size={14} style={{ color: 'var(--success)' }} />
                  : <XCircle    size={14} style={{ color: 'var(--danger)'  }} />
                }
              </span>
            </motion.div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {logs.length === 50 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: 10, marginTop: 20 }}>
          <button className="btn btn-ghost" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
            Previous
          </button>
          <span style={{ color: 'var(--silver)', fontSize: 12, padding: '10px 16px' }}>Page {page}</span>
          <button className="btn btn-ghost" onClick={() => setPage(p => p + 1)}>
            Next
          </button>
        </div>
      )}
    </div>
  );
}
