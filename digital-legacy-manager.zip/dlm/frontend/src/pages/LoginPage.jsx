// frontend/src/pages/LoginPage.jsx
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMsal } from '@azure/msal-react';
import { motion } from 'framer-motion';
import { Shield, Eye, EyeOff } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { loginRequest } from '@/config/msalConfig';
import api from '@/config/api';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [showPw,   setShowPw]   = useState(false);
  const [loading,  setLoading]  = useState(false);

  const { login, updateUser } = useAuthStore();
  const { instance } = useMsal();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    const result = await login(email, password);
    setLoading(false);
    if (result.success) {
      toast.success('Welcome back.');
      navigate('/dashboard');
    } else {
      toast.error(result.error || 'Login failed.');
    }
  }

  async function handleAzureLogin() {
    try {
      const result = await instance.loginPopup(loginRequest);
      // Exchange Azure token for DLM token
      const { data } = await api.post('/api/auth/azure', {
        accessToken: result.accessToken,
        account:     result.account,
      });
      sessionStorage.setItem('accessToken', data.accessToken);
      updateUser(data.user);
      toast.success('Signed in with Microsoft.');
      navigate('/dashboard');
    } catch (err) {
      if (err.errorCode !== 'user_cancelled') {
        toast.error('Microsoft login failed.');
      }
    }
  }

  return (
    <div
      style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'var(--obsidian)', padding: 20,
      }}
    >
      {/* Background grid */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none',
        backgroundImage: 'linear-gradient(rgba(201,168,76,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(201,168,76,0.03) 1px, transparent 1px)',
        backgroundSize: '48px 48px',
      }} />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        style={{ width: '100%', maxWidth: 400, position: 'relative', zIndex: 1 }}
      >
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{
            width: 52, height: 52, background: 'rgba(201,168,76,0.1)',
            border: '1px solid var(--border-bright)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 16,
          }}>
            <Shield size={24} style={{ color: 'var(--gold)' }} />
          </div>
          <h1 style={{ fontSize: 24, color: 'var(--ivory)', margin: '0 0 6px', fontFamily: 'monospace' }}>
            Digital Legacy Manager
          </h1>
          <p style={{ fontSize: 12, color: 'var(--silver)', letterSpacing: '0.1em' }}>
            SIGN IN TO YOUR VAULT
          </p>
        </div>

        {/* Form */}
        <div className="card" style={{ padding: 32 }}>
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <label style={{ display: 'block', fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 6 }}>
                EMAIL
              </label>
              <input
                className="input"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                autoComplete="email"
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: 10, color: 'var(--gold)', letterSpacing: '0.2em', marginBottom: 6 }}>
                PASSWORD
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  className="input"
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  autoComplete="current-password"
                  style={{ paddingRight: 44 }}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(v => !v)}
                  style={{
                    position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
                    background: 'none', border: 'none', color: 'var(--silver)', cursor: 'pointer',
                  }}
                >
                  {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button
              className="btn btn-primary"
              type="submit"
              disabled={loading}
              style={{ width: '100%', justifyContent: 'center', marginTop: 4 }}
            >
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>

          {/* Divider */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '20px 0' }}>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
            <span style={{ fontSize: 10, color: 'var(--gold-dim)', letterSpacing: '0.2em' }}>OR</span>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
          </div>

          {/* Azure AD */}
          <button
            className="btn btn-ghost"
            onClick={handleAzureLogin}
            style={{ width: '100%', justifyContent: 'center' }}
          >
            <img
              src="https://learn.microsoft.com/en-us/azure/active-directory/develop/media/howto-add-branding-in-apps/ms-symbollockup_mssymbol_19.svg"
              alt="Microsoft"
              style={{ width: 16, height: 16 }}
              onError={e => e.target.style.display = 'none'}
            />
            Sign in with Microsoft
          </button>
        </div>

        <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--silver)', marginTop: 20 }}>
          No account?{' '}
          <Link to="/register" style={{ color: 'var(--gold)', textDecoration: 'none' }}>
            Register here
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
