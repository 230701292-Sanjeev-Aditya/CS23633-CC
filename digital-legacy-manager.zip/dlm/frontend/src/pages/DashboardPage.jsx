// frontend/src/pages/DashboardPage.jsx
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, Lock, Unlock, Archive, Clock, AlertTriangle, ChevronRight } from 'lucide-react';
import { useVaultStore } from '@/store/vaultStore';
import { useAuthStore  } from '@/store/authStore';
import { formatDistanceToNow, format } from 'date-fns';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import CreateVaultModal from '@/components/vaults/CreateVaultModal';

const STATUS_ICON = {
  active:   <Lock   size={14} style={{ color: 'var(--success)' }} />,
  released: <Unlock size={14} style={{ color: 'var(--azure)'   }} />,
  archived: <Archive size={14} style={{ color: 'var(--silver)' }} />,
};

const COLORS = ['#c9a84c', '#4d8fff', '#3cc962', '#e05260', '#00ad9f'];

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export default function DashboardPage() {
  const { vaults, fetchVaults, isLoading } = useVaultStore();
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [showCreate, setShowCreate] = useState(false);

  useEffect(() => { fetchVaults(); }, []);

  const activeVaults   = vaults.filter(v => v.status === 'active').length;
  const releasedVaults = vaults.filter(v => v.status === 'released').length;
  const totalAssets    = vaults.reduce((s, v) => s + (v.assetCount || 0), 0);
  const totalSize      = vaults.reduce((s, v) => s + (v.totalSizeBytes || 0), 0);

  const pieData = vaults.slice(0, 5).map((v, i) => ({
    name:  v.name,
    value: Math.max(v.assetCount || 1, 1),
    color: COLORS[i % COLORS.length],
  }));

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto' }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 32 }}>
        <div>
          <div style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.3em', marginBottom: 4 }}>
            WELCOME BACK
          </div>
          <h1 style={{ fontSize: 26, color: 'var(--ivory)', margin: 0 }}>
            {user?.displayName}
          </h1>
        </div>
        <button className="btn btn-primary" onClick={() => setShowCreate(true)}>
          <Plus size={14} /> New Vault
        </button>
      </div>

      {/* Stat cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 1, marginBottom: 28 }}>
        {[
          { label: 'Active Vaults',   value: activeVaults,   color: 'var(--success)' },
          { label: 'Released Vaults', value: releasedVaults, color: 'var(--azure)'   },
          { label: 'Total Assets',    value: totalAssets,    color: 'var(--gold)'    },
          { label: 'Storage Used',    value: formatBytes(totalSize), color: 'var(--silver)', str: true },
        ].map(({ label, value, color, str }) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y:  0 }}
            className="card"
            style={{ padding: '20px 22px' }}
          >
            <div style={{ fontSize: 10, color: 'var(--gold-dim)', letterSpacing: '0.2em', marginBottom: 8 }}>
              {label.toUpperCase()}
            </div>
            <div style={{ fontSize: str ? 22 : 32, color, fontWeight: 600, lineHeight: 1 }}>
              {value}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Content grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 20 }}>

        {/* Vault list */}
        <div>
          <div style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.25em', marginBottom: 14 }}>
            YOUR VAULTS
          </div>

          {isLoading && (
            <div style={{ color: 'var(--silver)', padding: 32, textAlign: 'center', fontSize: 12 }}>
              Loading vaults…
            </div>
          )}

          {!isLoading && vaults.length === 0 && (
            <div className="card" style={{ textAlign: 'center', padding: 48 }}>
              <Lock size={32} style={{ color: 'var(--gold-dim)', margin: '0 auto 16px' }} />
              <div style={{ color: 'var(--silver)', fontSize: 13, marginBottom: 16 }}>
                No vaults yet. Create your first legacy vault.
              </div>
              <button className="btn btn-primary" onClick={() => setShowCreate(true)}>
                <Plus size={13} /> Create Vault
              </button>
            </div>
          )}

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {vaults.map((vault, i) => (
              <motion.div
                key={vault._id}
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04 }}
                className="card"
                onClick={() => navigate(`/vaults/${vault._id}`)}
                style={{ cursor: 'pointer', padding: '18px 20px' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div style={{
                    width: 36, height: 36, flexShrink: 0,
                    background: 'rgba(201,168,76,0.08)',
                    border: '1px solid var(--border)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {STATUS_ICON[vault.status] || STATUS_ICON.active}
                  </div>

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3 }}>
                      <span style={{ fontSize: 14, color: 'var(--ivory)', fontWeight: 500 }}>
                        {vault.name}
                      </span>
                      <span className={`badge badge-${vault.status}`}>{vault.status}</span>
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--silver)' }}>
                      {vault.assetCount || 0} assets · {formatBytes(vault.totalSizeBytes || 0)} ·{' '}
                      <span style={{ color: 'var(--gold-dim)' }}>
                        {vault.trigger?.type === 'inactivity' && (
                          <><Clock size={10} style={{ display: 'inline', verticalAlign: 'middle' }} /> Inactivity trigger</>
                        )}
                        {vault.trigger?.type === 'time_lock' && vault.trigger?.releaseAt && (
                          <><Clock size={10} style={{ display: 'inline', verticalAlign: 'middle' }} /> Releases {format(new Date(vault.trigger.releaseAt), 'MMM d, yyyy')}</>
                        )}
                      </span>
                    </div>
                  </div>

                  <ChevronRight size={16} style={{ color: 'var(--gold-dim)', flexShrink: 0 }} />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Sidebar: chart + last check-in */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {vaults.length > 0 && (
            <div className="card" style={{ padding: 20 }}>
              <div style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.25em', marginBottom: 14 }}>
                ASSET DISTRIBUTION
              </div>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={65}
                    paddingAngle={3} dataKey="value">
                    {pieData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} stroke="transparent" />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 0, fontSize: 11 }}
                    labelStyle={{ color: 'var(--ivory)' }}
                    itemStyle={{ color: 'var(--silver)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
              {pieData.map((d, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
                  <div style={{ width: 8, height: 8, background: d.color, flexShrink: 0 }} />
                  <span style={{ fontSize: 11, color: 'var(--silver)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {d.name}
                  </span>
                  <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--gold)' }}>{d.value}</span>
                </div>
              ))}
            </div>
          )}

          {/* Check-in status */}
          <div className="card" style={{ padding: 20 }}>
            <div style={{ fontSize: 10, color: 'var(--gold)', letterSpacing: '0.25em', marginBottom: 12 }}>
              INACTIVITY STATUS
            </div>
            {user?.lastCheckIn ? (
              <>
                <div style={{ fontSize: 12, color: 'var(--silver)', marginBottom: 6 }}>
                  Last check-in:
                </div>
                <div style={{ fontSize: 13, color: 'var(--ivory)', marginBottom: 12 }}>
                  {formatDistanceToNow(new Date(user.lastCheckIn), { addSuffix: true })}
                </div>
                <div style={{ fontSize: 10, color: 'var(--success)', display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{ width: 6, height: 6, background: 'var(--success)', borderRadius: '50%' }} />
                  Timer active — you're alive 🤍
                </div>
              </>
            ) : (
              <div style={{ fontSize: 12, color: 'var(--danger)', display: 'flex', alignItems: 'center', gap: 6 }}>
                <AlertTriangle size={13} /> No check-in recorded yet
              </div>
            )}
          </div>
        </div>
      </div>

      {showCreate && <CreateVaultModal onClose={() => setShowCreate(false)} />}
    </div>
  );
}
