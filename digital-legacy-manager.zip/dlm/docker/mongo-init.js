// docker/mongo-init.js — runs once on first container start
db = db.getSiblingDB('dlm');

db.createCollection('users');
db.createCollection('vaults');
db.createCollection('assets');
db.createCollection('beneficiaries');
db.createCollection('auditlogs');

// Indexes
db.users.createIndex({ email: 1 }, { unique: true });
db.vaults.createIndex({ owner: 1 });
db.assets.createIndex({ vault: 1 });
db.auditlogs.createIndex({ user: 1, createdAt: -1 });
db.auditlogs.createIndex({ createdAt: 1 }, { expireAfterSeconds: 31536000 }); // 1-year TTL

print('DLM database initialized.');
