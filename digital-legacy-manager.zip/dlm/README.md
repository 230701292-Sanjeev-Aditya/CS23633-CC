# 🔐 Digital Legacy Manager (DLM)

A cloud-native platform to securely store, manage, and transfer your digital assets to trusted beneficiaries.

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite + Tailwind CSS → **Netlify** |
| Backend API | Node.js + Express.js → **Azure App Service** |
| Auth | **Azure Active Directory** (OAuth 2.0 / OIDC) |
| Secrets | **Azure Key Vault** |
| Database | MongoDB Atlas (Mongoose) |
| File Storage | **Azure Blob Storage** |
| Containers | **Docker** + docker-compose |
| CI/CD | GitHub Actions → Netlify + Azure |

## Project Structure

```
dlm/
├── frontend/          # React 18 SPA (deployed to Netlify)
├── backend/           # Node.js/Express REST API (Azure App Service)
├── worker/            # Legacy release background worker
├── docker/            # Dockerfiles
├── .github/workflows/ # CI/CD pipelines
└── docker-compose.yml # Local development orchestration
```

## Quick Start

```bash
# Clone and install
git clone https://github.com/your-org/digital-legacy-manager.git
cd digital-legacy-manager

# Copy env files
cp .env.example .env

# Start all services
docker-compose up --build
```

- Frontend: http://localhost:3000
- API: http://localhost:5000
- API Docs: http://localhost:5000/api-docs

## Environment Variables

See `.env.example` for all required variables.
