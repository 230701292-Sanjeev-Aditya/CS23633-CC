// worker/src/index.js
require('dotenv').config();
const mongoose = require('mongoose');
const cron     = require('node-cron');
const sgMail   = require('@sendgrid/mail');

// Inline minimal models (worker is a separate service)
const vaultSchema = new mongoose.Schema({
  owner:   mongoose.Schema.Types.ObjectId,
  name:    String,
  status:  String,
  trigger: {
    type:           String,
    releaseAt:      Date,
    inactivityDays: Number,
    triggered:      Boolean,
    triggeredAt:    Date,
  },
}, { timestamps: true });

const userSchema = new mongoose.Schema({
  email:       String,
  displayName: String,
  lastCheckIn: Date,
  isActive:    Boolean,
});

const beneficiarySchema = new mongoose.Schema({
  vault:           mongoose.Schema.Types.ObjectId,
  name:            String,
  email:           String,
  role:            String,
  inviteStatus:    String,
  notifyOnRelease: Boolean,
});

const Vault       = mongoose.model('Vault', vaultSchema);
const User        = mongoose.model('User',  userSchema);
const Beneficiary = mongoose.model('Beneficiary', beneficiarySchema);

const INTERVAL_MS         = parseInt(process.env.CHECK_INTERVAL_MS || '3600000'); // 1 hr
const WARN_DAYS           = parseInt(process.env.INACTIVITY_WARNING_DAYS || '30');
const RELEASE_DAYS        = parseInt(process.env.INACTIVITY_RELEASE_DAYS || '60');
const FRONTEND_URL        = process.env.FRONTEND_URL || 'https://dlm.netlify.app';

if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

async function sendEmail(to, subject, html) {
  if (!process.env.SENDGRID_API_KEY) {
    console.log(`[EMAIL MOCK] To: ${to}\nSubject: ${subject}`);
    return;
  }
  await sgMail.send({ to, from: process.env.FROM_EMAIL, subject, html });
}

/**
 * Release a vault: mark it released, notify all beneficiaries.
 */
async function releaseVault(vault, owner, reason) {
  console.log(`[WORKER] Releasing vault ${vault._id} (${reason})`);

  vault.status        = 'released';
  vault.trigger.triggered   = true;
  vault.trigger.triggeredAt = new Date();
  await vault.save();

  const beneficiaries = await Beneficiary.find({
    vault:           vault._id,
    inviteStatus:    'accepted',
    notifyOnRelease: true,
  });

  for (const b of beneficiaries) {
    await sendEmail(
      b.email,
      `Digital Legacy Vault Released – ${vault.name}`,
      `<h2>Hello ${b.name},</h2>
       <p>${owner.displayName}'s digital legacy vault <strong>"${vault.name}"</strong>
       has been released to you.</p>
       <p><a href="${FRONTEND_URL}/beneficiary/access/${vault._id}">Access Your Inheritance</a></p>
       <p>Reason: <em>${reason}</em></p>`
    );
    console.log(`[WORKER] Notified beneficiary: ${b.email}`);
  }
}

/**
 * Send a warning email to the owner before inactivity release.
 */
async function sendInactivityWarning(owner, vault, daysLeft) {
  await sendEmail(
    owner.email,
    `Action Required: Your Legacy Vault Will Release in ${daysLeft} Days`,
    `<h2>Hi ${owner.displayName},</h2>
     <p>Your vault <strong>"${vault.name}"</strong> is scheduled to release in
     <strong>${daysLeft} day(s)</strong> due to inactivity.</p>
     <p><a href="${FRONTEND_URL}/checkin">Click here to check in</a> and reset the timer.</p>`
  );
}

/**
 * Main worker logic — runs every INTERVAL_MS.
 */
async function runChecks() {
  console.log(`[WORKER] Running checks at ${new Date().toISOString()}`);

  const activeVaults = await Vault.find({ status: 'active' });

  for (const vault of activeVaults) {
    const owner = await User.findById(vault.owner);
    if (!owner || !owner.isActive) continue;

    const { type, releaseAt, inactivityDays } = vault.trigger;

    // ── Time-lock trigger ─────────────────────────────
    if (type === 'time_lock' && releaseAt && new Date() >= new Date(releaseAt)) {
      await releaseVault(vault, owner, 'Time-lock date reached');
      continue;
    }

    // ── Inactivity trigger ────────────────────────────
    if (type === 'inactivity') {
      const lastCheckIn = new Date(owner.lastCheckIn);
      const daysSince   = (Date.now() - lastCheckIn.getTime()) / (1000 * 60 * 60 * 24);
      const threshold   = inactivityDays || RELEASE_DAYS;
      const warnAt      = threshold - (RELEASE_DAYS - WARN_DAYS);

      if (daysSince >= threshold) {
        await releaseVault(vault, owner, `Owner inactive for ${Math.floor(daysSince)} days`);
      } else if (daysSince >= warnAt) {
        const daysLeft = Math.ceil(threshold - daysSince);
        await sendInactivityWarning(owner, vault, daysLeft);
        console.log(`[WORKER] Warned owner ${owner.email} — ${daysLeft} days left`);
      }
    }
  }

  console.log(`[WORKER] Check complete. Processed ${activeVaults.length} vaults.`);
}

// ── Bootstrap ─────────────────────────────────────────
async function main() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('[WORKER] Connected to MongoDB');

  // Run immediately on start, then on schedule
  await runChecks();

  // Schedule: every hour using node-cron
  cron.schedule('0 * * * *', runChecks);
  console.log('[WORKER] Scheduled hourly checks.');
}

main().catch(err => {
  console.error('[WORKER] Fatal error:', err);
  process.exit(1);
});
