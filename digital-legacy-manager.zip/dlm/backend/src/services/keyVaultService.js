// backend/src/services/keyVaultService.js
const { DefaultAzureCredential } = require('@azure/identity');
const { SecretClient }           = require('@azure/keyvault-secrets');
const logger = require('../config/logger');

let secretClient;

function getClient() {
  if (!secretClient) {
    const credential = new DefaultAzureCredential();
    secretClient = new SecretClient(
      process.env.AZURE_KEYVAULT_URI,
      credential
    );
  }
  return secretClient;
}

/**
 * Retrieve a secret from Azure Key Vault.
 * Falls back to process.env in development.
 */
async function getSecret(name) {
  if (process.env.NODE_ENV !== 'production') {
    return process.env[name] || null;
  }
  try {
    const secret = await getClient().getSecret(name);
    return secret.value;
  } catch (err) {
    logger.error(`KeyVault: failed to get secret "${name}":`, err.message);
    throw err;
  }
}

/**
 * Store or update a secret in Key Vault.
 */
async function setSecret(name, value) {
  try {
    await getClient().setSecret(name, value);
    logger.info(`KeyVault: secret "${name}" stored.`);
  } catch (err) {
    logger.error(`KeyVault: failed to set secret "${name}":`, err.message);
    throw err;
  }
}

/**
 * Delete a secret (soft delete by default in Key Vault).
 */
async function deleteSecret(name) {
  try {
    const poller = await getClient().beginDeleteSecret(name);
    await poller.pollUntilDone();
    logger.info(`KeyVault: secret "${name}" deleted.`);
  } catch (err) {
    logger.error(`KeyVault: failed to delete secret "${name}":`, err.message);
    throw err;
  }
}

module.exports = { getSecret, setSecret, deleteSecret };
