// backend/src/services/blobService.js
const { BlobServiceClient, generateBlobSASQueryParameters,
        BlobSASPermissions, StorageSharedKeyCredential } = require('@azure/storage-blob');
const { v4: uuidv4 } = require('uuid');
const path   = require('path');
const logger = require('../config/logger');

let blobServiceClient;

function getClient() {
  if (!blobServiceClient) {
    blobServiceClient = BlobServiceClient.fromConnectionString(
      process.env.AZURE_STORAGE_CONNECTION_STRING
    );
  }
  return blobServiceClient;
}

/**
 * Upload a file buffer to Azure Blob Storage.
 * Returns the blob name (key) for storage in MongoDB.
 */
async function uploadAsset(userId, fileBuffer, originalName, mimeType) {
  const container = getClient().getContainerClient(
    process.env.AZURE_STORAGE_CONTAINER
  );
  await container.createIfNotExists({ access: 'None' });

  const ext      = path.extname(originalName);
  const blobName = `${userId}/${uuidv4()}${ext}`;

  const blockBlob = container.getBlockBlobClient(blobName);
  await blockBlob.uploadData(fileBuffer, {
    blobHTTPHeaders: { blobContentType: mimeType },
    metadata: { originalName, uploadedBy: userId },
  });

  logger.info(`Blob uploaded: ${blobName}`);
  return blobName;
}

/**
 * Generate a time-limited SAS URL for secure asset download.
 */
async function generateDownloadUrl(blobName, expiresInMinutes = 15) {
  const container  = process.env.AZURE_STORAGE_CONTAINER;
  const accountName = process.env.AZURE_STORAGE_ACCOUNT_NAME;
  const accountKey  = process.env.AZURE_STORAGE_ACCOUNT_KEY;

  const sharedKeyCredential = new StorageSharedKeyCredential(accountName, accountKey);
  const expiresOn = new Date(Date.now() + expiresInMinutes * 60 * 1000);

  const sasToken = generateBlobSASQueryParameters(
    {
      containerName: container,
      blobName,
      permissions: BlobSASPermissions.parse('r'),
      expiresOn,
    },
    sharedKeyCredential
  ).toString();

  return `https://${accountName}.blob.core.windows.net/${container}/${blobName}?${sasToken}`;
}

/**
 * Permanently delete a blob.
 */
async function deleteAsset(blobName) {
  const container = getClient().getContainerClient(
    process.env.AZURE_STORAGE_CONTAINER
  );
  await container.deleteBlob(blobName);
  logger.info(`Blob deleted: ${blobName}`);
}

module.exports = { uploadAsset, generateDownloadUrl, deleteAsset };
