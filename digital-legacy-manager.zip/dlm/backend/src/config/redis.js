// backend/src/config/redis.js
const { createClient } = require('redis');
const logger = require('./logger');

let client;

async function connectRedis() {
  client = createClient({ url: process.env.REDIS_URL });

  client.on('error', err => logger.error('Redis error:', err));
  client.on('connect', () => logger.info('Redis connected'));
  client.on('reconnecting', () => logger.warn('Redis reconnecting...'));

  await client.connect();
  return client;
}

function getRedisClient() {
  if (!client) throw new Error('Redis not initialised. Call connectRedis() first.');
  return client;
}

module.exports = connectRedis;
module.exports.getRedisClient = getRedisClient;
