// backend/src/controllers/authController.js
const jwt    = require('jsonwebtoken');
const crypto = require('crypto');
const User   = require('../models/User');
const { getRedisClient } = require('../config/redis');
const logger = require('../config/logger');

// ── Token helpers ─────────────────────────────────────

function generateAccessToken(userId) {
  return jwt.sign({ sub: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '15m',
    issuer: 'dlm-api',
  });
}

function generateRefreshToken() {
  return crypto.randomBytes(64).toString('hex');
}

function setTokenCookies(res, accessToken, refreshToken) {
  const isProd = process.env.NODE_ENV === 'production';
  res.cookie('accessToken', accessToken, {
    httpOnly: true,
    secure:   isProd,
    sameSite: 'strict',
    maxAge:   15 * 60 * 1000, // 15 min
  });
  res.cookie('refreshToken', refreshToken, {
    httpOnly: true,
    secure:   isProd,
    sameSite: 'strict',
    maxAge:   7 * 24 * 60 * 60 * 1000, // 7 days
  });
}

// ── Controllers ───────────────────────────────────────

/**
 * POST /api/auth/register
 */
async function register(req, res) {
  const { email, password, displayName } = req.body;

  const existing = await User.findOne({ email });
  if (existing) {
    return res.status(409).json({ error: 'Email already registered.' });
  }

  const user = await User.create({
    email,
    displayName,
    passwordHash: password, // pre-save hook hashes it
    provider: 'local',
  });

  await req.audit('register', `user:${user._id}`);

  const accessToken  = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken();

  // Store hashed refresh token
  const hashed = crypto.createHash('sha256').update(refreshToken).digest('hex');
  user.refreshTokens.push(hashed);
  await user.save();

  setTokenCookies(res, accessToken, refreshToken);

  res.status(201).json({
    message: 'Registration successful.',
    user: user.toPublicJSON(),
    accessToken,
  });
}

/**
 * POST /api/auth/login
 */
async function login(req, res) {
  const { email, password } = req.body;

  const user = await User.findOne({ email, provider: 'local', deletedAt: null });
  if (!user || !(await user.verifyPassword(password))) {
    await req.audit('login', null, { email }, false, 'Invalid credentials');
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  if (!user.isActive) {
    return res.status(403).json({ error: 'Account is deactivated.' });
  }

  // Update check-in
  user.lastCheckIn  = new Date();
  user.checkInCount += 1;

  const accessToken  = generateAccessToken(user._id);
  const refreshToken = generateRefreshToken();
  const hashed = crypto.createHash('sha256').update(refreshToken).digest('hex');

  // Keep last 5 refresh tokens (multi-device support)
  user.refreshTokens = [...user.refreshTokens.slice(-4), hashed];
  await user.save();

  setTokenCookies(res, accessToken, refreshToken);
  await req.audit('login', `user:${user._id}`);

  res.json({ message: 'Login successful.', user: user.toPublicJSON(), accessToken });
}

/**
 * POST /api/auth/refresh
 */
async function refreshToken(req, res) {
  const token = req.cookies?.refreshToken;
  if (!token) return res.status(401).json({ error: 'No refresh token.' });

  const hashed = crypto.createHash('sha256').update(token).digest('hex');
  const user   = await User.findOne({ refreshTokens: hashed, isActive: true });

  if (!user) {
    return res.status(401).json({ error: 'Invalid or expired refresh token.' });
  }

  // Rotate refresh token
  user.refreshTokens = user.refreshTokens.filter(t => t !== hashed);
  const newRefresh   = generateRefreshToken();
  const newHashed    = crypto.createHash('sha256').update(newRefresh).digest('hex');
  user.refreshTokens.push(newHashed);
  await user.save();

  const accessToken = generateAccessToken(user._id);
  setTokenCookies(res, accessToken, newRefresh);

  res.json({ accessToken });
}

/**
 * POST /api/auth/logout
 */
async function logout(req, res) {
  const redis = getRedisClient();

  // Blacklist the current access token until it expires
  if (req.token) {
    const decoded = jwt.decode(req.token);
    const ttl     = (decoded.exp - Math.floor(Date.now() / 1000));
    if (ttl > 0) {
      await redis.set(`blacklist:${req.token}`, '1', { EX: ttl });
    }
  }

  // Remove refresh token
  const refreshToken = req.cookies?.refreshToken;
  if (refreshToken && req.user) {
    const hashed = crypto.createHash('sha256').update(refreshToken).digest('hex');
    await User.findByIdAndUpdate(req.user._id, {
      $pull: { refreshTokens: hashed },
    });
  }

  res.clearCookie('accessToken');
  res.clearCookie('refreshToken');
  await req.audit('logout', `user:${req.user._id}`);
  res.json({ message: 'Logged out successfully.' });
}

/**
 * POST /api/auth/checkin
 * Owner presses the "I'm alive" button — resets inactivity timer.
 */
async function checkIn(req, res) {
  req.user.lastCheckIn   = new Date();
  req.user.checkInCount += 1;
  await req.user.save();
  await req.audit('checkin', `user:${req.user._id}`);
  res.json({ message: 'Check-in recorded.', lastCheckIn: req.user.lastCheckIn });
}

module.exports = { register, login, refreshToken, logout, checkIn };
