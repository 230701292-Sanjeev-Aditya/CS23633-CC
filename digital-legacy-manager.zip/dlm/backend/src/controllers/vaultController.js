// backend/src/controllers/vaultController.js
const { v4: uuidv4 } = require('uuid');
const Vault   = require('../models/Vault');
const Asset   = require('../models/Asset');
const { setSecret, deleteSecret } = require('../services/keyVaultService');

/**
 * GET /api/vaults
 */
async function listVaults(req, res) {
  const vaults = await Vault.find({ owner: req.user._id, status: { $ne: 'archived' } })
    .sort({ createdAt: -1 })
    .lean();
  res.json({ vaults });
}

/**
 * POST /api/vaults
 */
async function createVault(req, res) {
  const { name, description, trigger } = req.body;

  // Generate vault encryption key and store in Azure Key Vault
  const keyRef    = `vault-key-${uuidv4()}`;
  const vaultKey  = require('crypto').randomBytes(32).toString('hex');
  await setSecret(keyRef, vaultKey);

  const vault = await Vault.create({
    owner: req.user._id,
    name,
    description,
    encryptionKeyRef: keyRef,
    trigger,
  });

  await req.audit('vault_create', `vault:${vault._id}`, { name });
  res.status(201).json({ vault });
}

/**
 * GET /api/vaults/:id
 */
async function getVault(req, res) {
  const vault = await Vault.findOne({ _id: req.params.id, owner: req.user._id })
    .populate('assets');

  if (!vault) return res.status(404).json({ error: 'Vault not found.' });

  await req.audit('vault_update', `vault:${vault._id}`, { action: 'view' });
  res.json({ vault });
}

/**
 * PATCH /api/vaults/:id
 */
async function updateVault(req, res) {
  const { name, description, trigger } = req.body;

  const vault = await Vault.findOneAndUpdate(
    { _id: req.params.id, owner: req.user._id },
    { $set: { name, description, trigger } },
    { new: true, runValidators: true }
  );

  if (!vault) return res.status(404).json({ error: 'Vault not found.' });

  await req.audit('vault_update', `vault:${vault._id}`);
  res.json({ vault });
}

/**
 * DELETE /api/vaults/:id
 * Soft-archive the vault and delete its encryption key from Key Vault.
 */
async function deleteVault(req, res) {
  const vault = await Vault.findOne({ _id: req.params.id, owner: req.user._id });
  if (!vault) return res.status(404).json({ error: 'Vault not found.' });

  vault.status = 'archived';
  await vault.save();

  // Delete encryption key from Azure Key Vault
  try {
    await deleteSecret(vault.encryptionKeyRef);
  } catch {
    // Log but don't block — key may already be gone
  }

  await req.audit('vault_delete', `vault:${vault._id}`);
  res.json({ message: 'Vault archived.' });
}

/**
 * GET /api/vaults/:id/stats
 */
async function getVaultStats(req, res) {
  const vault = await Vault.findOne({ _id: req.params.id, owner: req.user._id });
  if (!vault) return res.status(404).json({ error: 'Vault not found.' });

  const breakdown = await Asset.aggregate([
    { $match: { vault: vault._id, deletedAt: null } },
    { $group: { _id: '$type', count: { $sum: 1 }, totalSize: { $sum: '$sizeBytes' } } },
  ]);

  res.json({
    vaultId:    vault._id,
    status:     vault.status,
    assetCount: vault.assetCount,
    totalSize:  vault.totalSizeBytes,
    breakdown,
    trigger:    vault.trigger,
  });
}

module.exports = { listVaults, createVault, getVault, updateVault, deleteVault, getVaultStats };
