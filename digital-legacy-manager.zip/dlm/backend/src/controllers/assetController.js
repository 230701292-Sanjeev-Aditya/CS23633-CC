// backend/src/controllers/assetController.js
const crypto  = require('crypto');
const multer  = require('multer');
const Asset   = require('../models/Asset');
const Vault   = require('../models/Vault');
const { uploadAsset, generateDownloadUrl, deleteAsset } = require('../services/blobService');

// ── Multer: memory storage (buffer → Azure Blob) ──────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 }, // 100 MB
  fileFilter(req, file, cb) {
    // Block executable types
    const blocked = ['.exe', '.bat', '.sh', '.cmd', '.ps1'];
    const ext = require('path').extname(file.originalname).toLowerCase();
    if (blocked.includes(ext)) {
      return cb(new Error('File type not permitted.'));
    }
    cb(null, true);
  },
}).single('file');

/**
 * POST /api/assets
 * Upload a file asset to Azure Blob + save metadata to MongoDB.
 */
async function uploadAssetHandler(req, res) {
  // Run multer middleware manually for error handling
  await new Promise((resolve, reject) => {
    upload(req, res, err => (err ? reject(err) : resolve()));
  });

  const { vaultId, name, type, description, tags, accessLevel } = req.body;

  // Verify vault ownership
  const vault = await Vault.findOne({ _id: vaultId, owner: req.user._id, status: 'active' });
  if (!vault) return res.status(404).json({ error: 'Vault not found or inactive.' });

  let blobName  = null;
  let sizeBytes = 0;
  let checksum  = null;
  let mimeType  = null;
  let encryptedData = req.body.encryptedData || null; // for structured assets

  if (req.file) {
    // Compute checksum before upload
    checksum  = crypto.createHash('sha256').update(req.file.buffer).digest('hex');
    sizeBytes = req.file.size;
    mimeType  = req.file.mimetype;
    blobName  = await uploadAsset(
      req.user._id.toString(),
      req.file.buffer,
      req.file.originalname,
      mimeType
    );
  }

  const asset = await Asset.create({
    vault:        vaultId,
    owner:        req.user._id,
    name,
    type,
    description,
    tags:         tags ? JSON.parse(tags) : [],
    blobName,
    mimeType,
    sizeBytes,
    checksum,
    encryptedData,
    accessLevel:  accessLevel || 'full',
  });

  // Update vault stats
  await Vault.findByIdAndUpdate(vaultId, {
    $inc: { assetCount: 1, totalSizeBytes: sizeBytes },
  });

  await req.audit('asset_upload', `asset:${asset._id}`, { vaultId, type, name });
  res.status(201).json({ asset });
}

/**
 * GET /api/assets?vaultId=:id
 */
async function listAssets(req, res) {
  const { vaultId, type, page = 1, limit = 20 } = req.query;

  const filter = {
    owner: req.user._id,
    deletedAt: null,
    ...(vaultId && { vault: vaultId }),
    ...(type    && { type }),
  };

  const [assets, total] = await Promise.all([
    Asset.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .lean(),
    Asset.countDocuments(filter),
  ]);

  res.json({ assets, total, page: Number(page), limit: Number(limit) });
}

/**
 * GET /api/assets/:id/download
 * Returns a time-limited SAS URL for the blob.
 */
async function downloadAsset(req, res) {
  const asset = await Asset.findOne({ _id: req.params.id, owner: req.user._id, deletedAt: null });
  if (!asset) return res.status(404).json({ error: 'Asset not found.' });

  if (!asset.blobName) {
    return res.json({ encryptedData: asset.encryptedData });
  }

  const url = await generateDownloadUrl(asset.blobName, 15);
  await req.audit('asset_view', `asset:${asset._id}`);
  res.json({ downloadUrl: url, expiresInMinutes: 15 });
}

/**
 * DELETE /api/assets/:id
 */
async function deleteAssetHandler(req, res) {
  const asset = await Asset.findOne({ _id: req.params.id, owner: req.user._id });
  if (!asset) return res.status(404).json({ error: 'Asset not found.' });

  // Soft delete
  asset.deletedAt = new Date();
  await asset.save();

  // Remove blob
  if (asset.blobName) {
    try { await deleteAsset(asset.blobName); } catch {}
  }

  // Update vault stats
  await Vault.findByIdAndUpdate(asset.vault, {
    $inc: { assetCount: -1, totalSizeBytes: -asset.sizeBytes },
  });

  await req.audit('asset_delete', `asset:${asset._id}`);
  res.json({ message: 'Asset deleted.' });
}

module.exports = { uploadAssetHandler, listAssets, downloadAsset, deleteAssetHandler };
