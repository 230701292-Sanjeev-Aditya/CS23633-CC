// backend/src/routes/vaults.js
const express = require('express');
const { body, param } = require('express-validator');
const { authenticate, attachAudit } = require('../middleware/auth');
const ctrl = require('../controllers/vaultController');

const router = express.Router();
router.use(authenticate, attachAudit);

router.get('/',       ctrl.listVaults);
router.post('/',
  [
    body('name').trim().notEmpty().isLength({ max: 100 }),
    body('trigger.type').isIn(['inactivity', 'time_lock', 'manual', 'legal']),
    body('trigger.releaseAt').optional().isISO8601(),
    body('trigger.inactivityDays').optional().isInt({ min: 7, max: 365 }),
  ],
  ctrl.createVault
);
router.get('/:id',        ctrl.getVault);
router.patch('/:id',      ctrl.updateVault);
router.delete('/:id',     ctrl.deleteVault);
router.get('/:id/stats',  ctrl.getVaultStats);

module.exports = router;
