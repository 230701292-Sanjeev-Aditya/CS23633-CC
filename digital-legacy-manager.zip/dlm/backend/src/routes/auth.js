// backend/src/routes/auth.js
const express  = require('express');
const { body, validationResult } = require('express-validator');
const { authenticate, attachAudit } = require('../middleware/auth');
const ctrl = require('../controllers/authController');

const router = express.Router();

// Validation helper
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array() });
  }
  next();
};

/**
 * @swagger
 * /api/auth/register:
 *   post:
 *     summary: Register a new user
 *     tags: [Auth]
 */
router.post('/register',
  attachAudit,
  [
    body('email').isEmail().normalizeEmail(),
    body('password')
      .isLength({ min: 12 })
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/)
      .withMessage('Password must be 12+ chars with upper, lower, digit, and special char.'),
    body('displayName').trim().isLength({ min: 2, max: 80 }),
  ],
  validate,
  ctrl.register
);

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     summary: Log in with email and password
 *     tags: [Auth]
 */
router.post('/login',
  attachAudit,
  [
    body('email').isEmail().normalizeEmail(),
    body('password').notEmpty(),
  ],
  validate,
  ctrl.login
);

/**
 * @swagger
 * /api/auth/refresh:
 *   post:
 *     summary: Refresh access token using refresh token cookie
 *     tags: [Auth]
 */
router.post('/refresh', ctrl.refreshToken);

/**
 * @swagger
 * /api/auth/logout:
 *   post:
 *     summary: Log out and revoke tokens
 *     tags: [Auth]
 */
router.post('/logout', authenticate, attachAudit, ctrl.logout);

/**
 * @swagger
 * /api/auth/checkin:
 *   post:
 *     summary: Record owner check-in to reset inactivity timer
 *     tags: [Auth]
 */
router.post('/checkin', authenticate, attachAudit, ctrl.checkIn);

module.exports = router;
