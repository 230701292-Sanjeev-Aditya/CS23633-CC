// backend/src/routes/assets.js
const express = require('express');
const { authenticate, attachAudit } = require('../middleware/auth');
const ctrl = require('../controllers/assetController');

const router = express.Router();
router.use(authenticate, attachAudit);

router.post('/',              ctrl.uploadAssetHandler);
router.get('/',               ctrl.listAssets);
router.get('/:id/download',   ctrl.downloadAsset);
router.delete('/:id',         ctrl.deleteAssetHandler);

module.exports = router;
