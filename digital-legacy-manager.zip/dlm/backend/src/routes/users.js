// backend/src/routes/users.js
const express = require('express');
const { body } = require('express-validator');
const { authenticate, attachAudit } = require('../middleware/auth');
const AuditLog = require('../models/AuditLog');
const User     = require('../models/User');

const router = express.Router();
router.use(authenticate, attachAudit);

// GET /api/users/me
router.get('/me', (req, res) => {
  res.json({ user: req.user.toPublicJSON() });
});

// PATCH /api/users/me
router.patch('/me',
  [body('displayName').optional().trim().isLength({ min: 2, max: 80 })],
  async (req, res) => {
    const { displayName, avatarUrl } = req.body;
    const updates = {};
    if (displayName) updates.displayName = displayName;
    if (avatarUrl)   updates.avatarUrl   = avatarUrl;

    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true });
    res.json({ user: user.toPublicJSON() });
  }
);

// GET /api/users/me/audit
router.get('/me/audit', async (req, res) => {
  const { page = 1, limit = 50 } = req.query;
  const logs = await AuditLog.find({ user: req.user._id })
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(Number(limit))
    .lean();
  res.json({ logs });
});

// DELETE /api/users/me  (GDPR right to erasure)
router.delete('/me', async (req, res) => {
  await User.findByIdAndUpdate(req.user._id, {
    deletedAt:    new Date(),
    isActive:     false,
    email:        `deleted_${req.user._id}@deleted.invalid`,
    displayName:  'Deleted User',
    refreshTokens: [],
  });
  await req.audit('logout', `user:${req.user._id}`, { reason: 'account_deleted' });
  res.clearCookie('accessToken');
  res.clearCookie('refreshToken');
  res.json({ message: 'Account deleted. All personal data has been anonymised.' });
});

module.exports = router;
