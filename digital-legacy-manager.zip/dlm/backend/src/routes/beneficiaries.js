// backend/src/routes/beneficiaries.js
const express = require('express');
const { body } = require('express-validator');
const { authenticate, attachAudit } = require('../middleware/auth');
const Beneficiary = require('../models/Beneficiary');
const Vault       = require('../models/Vault');
const crypto      = require('crypto');
const sgMail      = require('@sendgrid/mail');

const router = express.Router();
router.use(authenticate, attachAudit);

// List beneficiaries for a vault
router.get('/', async (req, res) => {
  const { vaultId } = req.query;
  const filter = { owner: req.user._id, ...(vaultId && { vault: vaultId }) };
  const list   = await Beneficiary.find(filter).sort({ createdAt: -1 });
  res.json({ beneficiaries: list });
});

// Invite a beneficiary
router.post('/',
  [
    body('email').isEmail().normalizeEmail(),
    body('name').trim().notEmpty(),
    body('vaultId').isMongoId(),
    body('role').isIn(['executor', 'viewer', 'partial']),
  ],
  async (req, res) => {
    const { email, name, vaultId, role, relation } = req.body;

    // Verify vault ownership
    const vault = await Vault.findOne({ _id: vaultId, owner: req.user._id });
    if (!vault) return res.status(404).json({ error: 'Vault not found.' });

    const inviteToken    = crypto.randomBytes(32).toString('hex');
    const inviteExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    const beneficiary = await Beneficiary.create({
      owner: req.user._id,
      vault: vaultId,
      name, email, role, relation,
      inviteToken,
      inviteExpiresAt,
    });

    // Send invite email (SendGrid)
    if (process.env.SENDGRID_API_KEY) {
      sgMail.setApiKey(process.env.SENDGRID_API_KEY);
      const inviteUrl = `${process.env.FRONTEND_URL}/invite/${inviteToken}`;
      await sgMail.send({
        to:      email,
        from:    process.env.FROM_EMAIL,
        subject: `You've been added as a beneficiary – Digital Legacy Manager`,
        html: `<p>Hi ${name},</p>
               <p>${req.user.displayName} has named you as a beneficiary of their digital legacy vault.</p>
               <p><a href="${inviteUrl}">Accept Invitation</a> (expires in 7 days)</p>`,
      }).catch(err => console.error('SendGrid error:', err.message));
    }

    await req.audit('beneficiary_invite', `beneficiary:${beneficiary._id}`, { email, role });
    res.status(201).json({ beneficiary });
  }
);

// Accept invite (public — no auth required)
router.post('/accept/:token', async (req, res) => {
  const b = await Beneficiary.findOne({
    inviteToken:     req.params.token,
    inviteStatus:    'pending',
    inviteExpiresAt: { $gt: new Date() },
  });
  if (!b) return res.status(404).json({ error: 'Invalid or expired invite.' });

  b.inviteStatus = 'accepted';
  b.acceptedAt   = new Date();
  b.inviteToken  = undefined;
  await b.save();

  res.json({ message: 'Invitation accepted.', beneficiary: b });
});

// Remove a beneficiary
router.delete('/:id', async (req, res) => {
  const b = await Beneficiary.findOneAndDelete({ _id: req.params.id, owner: req.user._id });
  if (!b) return res.status(404).json({ error: 'Beneficiary not found.' });
  res.json({ message: 'Beneficiary removed.' });
});

module.exports = router;
