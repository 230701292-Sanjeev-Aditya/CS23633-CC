// backend/src/server.js
require('dotenv').config();
require('express-async-errors');

const express    = require('express');
const helmet     = require('helmet');
const cors       = require('cors');
const morgan     = require('morgan');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const rateLimit  = require('express-rate-limit');
const swaggerUi  = require('swagger-ui-express');

const connectDB   = require('./config/database');
const connectRedis = require('./config/redis');
const { swaggerSpec } = require('./config/swagger');
const logger      = require('./config/logger');
const errorHandler = require('./middleware/errorHandler');

// Routes
const authRoutes        = require('./routes/auth');
const vaultRoutes       = require('./routes/vaults');
const assetRoutes       = require('./routes/assets');
const beneficiaryRoutes = require('./routes/beneficiaries');
const userRoutes        = require('./routes/users');

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Security middleware ───────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
}));
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(morgan('combined', { stream: { write: msg => logger.info(msg.trim()) } }));

// ── Rate limiting ─────────────────────────────────────
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please try again later.' },
});
app.use('/api/', limiter);

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10 });
app.use('/api/auth/', authLimiter);

// ── Health check ──────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), version: '1.0.0' });
});

// ── API Docs ──────────────────────────────────────────
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// ── Routes ────────────────────────────────────────────
app.use('/api/auth',         authRoutes);
app.use('/api/vaults',       vaultRoutes);
app.use('/api/assets',       assetRoutes);
app.use('/api/beneficiaries', beneficiaryRoutes);
app.use('/api/users',        userRoutes);

// ── 404 handler ───────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// ── Global error handler ──────────────────────────────
app.use(errorHandler);

// ── Start ─────────────────────────────────────────────
async function start() {
  await connectDB();
  await connectRedis();
  app.listen(PORT, () => {
    logger.info(`DLM API running on port ${PORT} [${process.env.NODE_ENV}]`);
  });
}

start().catch(err => {
  logger.error('Failed to start server', err);
  process.exit(1);
});

module.exports = app;
