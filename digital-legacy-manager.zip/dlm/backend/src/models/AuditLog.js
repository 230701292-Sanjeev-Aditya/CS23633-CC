// backend/src/models/AuditLog.js
const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema(
  {
    user:      { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    action:    {
      type: String,
      enum: [
        'login', 'logout', 'register',
        'vault_create', 'vault_update', 'vault_delete',
        'asset_upload', 'asset_view', 'asset_delete',
        'beneficiary_invite', 'beneficiary_accept',
        'vault_release', 'checkin',
        'password_change', 'mfa_enable', 'mfa_disable',
        'export_inventory',
      ],
      required: true,
    },
    resource:  { type: String },   // e.g. "vault:<id>"
    metadata:  { type: Object },   // extra context (IP, user-agent, etc.)
    ip:        { type: String },
    userAgent: { type: String },
    success:   { type: Boolean, default: true },
    error:     { type: String },
  },
  { timestamps: true }
);

auditLogSchema.index({ user: 1, createdAt: -1 });
// TTL: auto-delete logs after 1 year
auditLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 365 * 24 * 3600 });

module.exports = mongoose.model('AuditLog', auditLogSchema);
