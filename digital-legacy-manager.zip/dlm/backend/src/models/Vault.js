// backend/src/models/Vault.js
const mongoose = require('mongoose');

const triggerSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['inactivity', 'time_lock', 'manual', 'legal'],
    required: true,
  },
  // For time_lock: specific date/time to release
  releaseAt: { type: Date },
  // For inactivity: days of no check-in before release
  inactivityDays: { type: Number, default: 60 },
  // Status
  triggered:   { type: Boolean, default: false },
  triggeredAt: { type: Date },
}, { _id: false });

const vaultSchema = new mongoose.Schema(
  {
    owner:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    name:        { type: String, required: true, trim: true, maxlength: 100 },
    description: { type: String, maxlength: 500 },

    // ── Encryption ────────────────────────────────────
    // The vault encryption key is stored in Azure Key Vault.
    // We store only the Key Vault secret name here.
    encryptionKeyRef: { type: String, required: true },

    // ── Trigger settings ──────────────────────────────
    trigger:     { type: triggerSchema, required: true },

    // ── Status ────────────────────────────────────────
    status: {
      type: String,
      enum: ['active', 'released', 'locked', 'archived'],
      default: 'active',
    },
    releasedAt: { type: Date },

    // ── Stats ─────────────────────────────────────────
    assetCount:    { type: Number, default: 0 },
    totalSizeBytes:{ type: Number, default: 0 },
  },
  { timestamps: true }
);

// Virtual: list of assets (populated on demand)
vaultSchema.virtual('assets', {
  ref: 'Asset',
  localField: '_id',
  foreignField: 'vault',
});

module.exports = mongoose.model('Vault', vaultSchema);
