// backend/src/models/User.js
const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    // ── Identity ─────────────────────────────────────
    email:        { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String },                // null if Azure AD-only login
    displayName:  { type: String, required: true },
    avatarUrl:    { type: String },

    // ── Azure AD ──────────────────────────────────────
    azureOid:     { type: String, index: true },   // Azure AD Object ID
    provider:     { type: String, enum: ['local', 'azure_ad'], default: 'local' },

    // ── Roles ─────────────────────────────────────────
    role:         { type: String, enum: ['owner', 'admin'], default: 'owner' },

    // ── Activity tracking ─────────────────────────────
    lastCheckIn:  { type: Date, default: Date.now },
    checkInCount: { type: Number, default: 0 },
    isActive:     { type: Boolean, default: true },

    // ── Security ──────────────────────────────────────
    mfaEnabled:   { type: Boolean, default: false },
    mfaSecret:    { type: String },                // encrypted TOTP secret
    refreshTokens: [{ type: String }],             // hashed refresh tokens

    // ── Soft delete ───────────────────────────────────
    deletedAt:    { type: Date },
  },
  { timestamps: true }
);

// Hash password before save
userSchema.pre('save', async function (next) {
  if (this.isModified('passwordHash') && this.passwordHash) {
    this.passwordHash = await bcrypt.hash(this.passwordHash, 12);
  }
  next();
});

// Instance method: verify password
userSchema.methods.verifyPassword = function (plain) {
  return bcrypt.compare(plain, this.passwordHash);
};

// Instance method: safe public profile (strip secrets)
userSchema.methods.toPublicJSON = function () {
  const obj = this.toObject();
  delete obj.passwordHash;
  delete obj.refreshTokens;
  delete obj.mfaSecret;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
