// backend/src/models/Beneficiary.js
const mongoose = require('mongoose');

const beneficiarySchema = new mongoose.Schema(
  {
    owner:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    vault:    { type: mongoose.Schema.Types.ObjectId, ref: 'Vault', required: true },

    // ── Beneficiary identity ──────────────────────────
    name:     { type: String, required: true, trim: true },
    email:    { type: String, required: true, lowercase: true, trim: true },
    phone:    { type: String },
    relation: { type: String, trim: true },       // e.g. "spouse", "child"

    // ── Access ────────────────────────────────────────
    role: {
      type: String,
      enum: ['executor', 'viewer', 'partial'],    // executor = full access
      default: 'viewer',
    },
    assetAccess: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Asset' }], // for partial

    // ── Invitation status ─────────────────────────────
    inviteStatus: {
      type: String,
      enum: ['pending', 'accepted', 'declined'],
      default: 'pending',
    },
    inviteToken:    { type: String },
    inviteExpiresAt:{ type: Date },
    acceptedAt:     { type: Date },

    // ── Notification prefs ────────────────────────────
    notifyOnRelease: { type: Boolean, default: true },
    notifyEmail:     { type: Boolean, default: true },
  },
  { timestamps: true }
);

beneficiarySchema.index({ owner: 1, vault: 1 });
beneficiarySchema.index({ email: 1, vault: 1 }, { unique: true });

module.exports = mongoose.model('Beneficiary', beneficiarySchema);
