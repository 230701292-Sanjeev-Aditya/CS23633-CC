// backend/src/models/Asset.js
const mongoose = require('mongoose');

const assetSchema = new mongoose.Schema(
  {
    vault:   { type: mongoose.Schema.Types.ObjectId, ref: 'Vault', required: true, index: true },
    owner:   { type: mongoose.Schema.Types.ObjectId, ref: 'User',  required: true },

    // ── Asset metadata ────────────────────────────────
    name:    { type: String, required: true, trim: true, maxlength: 200 },
    type: {
      type: String,
      enum: ['document', 'photo', 'video', 'password', 'crypto_wallet',
             'social_account', 'message', 'financial', 'other'],
      required: true,
    },
    description: { type: String, maxlength: 1000 },
    tags:        [{ type: String, lowercase: true, trim: true }],

    // ── File assets (stored in Azure Blob) ────────────
    blobName:    { type: String },          // Azure Blob Storage key
    mimeType:    { type: String },
    sizeBytes:   { type: Number, default: 0 },
    checksum:    { type: String },          // SHA-256 of original file

    // ── Structured assets (passwords, accounts, etc.) ─
    // Stored client-side AES-256 encrypted; server never sees plaintext
    encryptedData: { type: String },        // base64-encoded ciphertext

    // ── Access control ────────────────────────────────
    accessLevel: {
      type: String,
      enum: ['full', 'view_only', 'restricted'],
      default: 'full',
    },
    allowedBeneficiaries: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Beneficiary' }],

    // ── Soft delete ───────────────────────────────────
    deletedAt: { type: Date },
  },
  { timestamps: true }
);

assetSchema.index({ vault: 1, type: 1 });
assetSchema.index({ owner: 1, deletedAt: 1 });

module.exports = mongoose.model('Asset', assetSchema);
