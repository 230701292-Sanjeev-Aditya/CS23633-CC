// backend/src/middleware/errorHandler.js
const logger = require('../config/logger');

/**
 * Centralised Express error handler.
 * Maps known error types to HTTP status codes.
 */
function errorHandler(err, req, res, next) {  // eslint-disable-line no-unused-vars
  logger.error({
    message: err.message,
    stack:   err.stack,
    method:  req.method,
    url:     req.originalUrl,
    userId:  req.user?._id,
  });

  // Mongoose validation error
  if (err.name === 'ValidationError') {
    const errors = Object.values(err.errors).map(e => ({
      field:   e.path,
      message: e.message,
    }));
    return res.status(422).json({ error: 'Validation failed.', errors });
  }

  // Mongoose duplicate key
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0];
    return res.status(409).json({ error: `${field} already exists.` });
  }

  // Mongoose CastError (invalid ObjectId)
  if (err.name === 'CastError') {
    return res.status(400).json({ error: `Invalid ${err.path}: ${err.value}` });
  }

  // JWT errors (should be caught upstream, but just in case)
  if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }

  // Azure SDK errors
  if (err.statusCode && err.statusCode < 500) {
    return res.status(err.statusCode).json({ error: err.message });
  }

  // Default: 500
  const isDev = process.env.NODE_ENV === 'development';
  res.status(500).json({
    error:  'An unexpected error occurred.',
    ...(isDev && { detail: err.message, stack: err.stack }),
  });
}

module.exports = errorHandler;
