// backend/src/middleware/auth.js
const jwt        = require('jsonwebtoken');
const User       = require('../models/User');
const AuditLog   = require('../models/AuditLog');
const { getRedisClient } = require('../config/redis');

/**
 * Verify JWT access token from Authorization header or cookie.
 */
async function authenticate(req, res, next) {
  try {
    let token = null;

    // 1. Check Authorization header
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.slice(7);
    }

    // 2. Fallback: HttpOnly cookie
    if (!token && req.cookies?.accessToken) {
      token = req.cookies.accessToken;
    }

    if (!token) {
      return res.status(401).json({ error: 'No authentication token provided.' });
    }

    // 3. Check blacklist (logged-out tokens) in Redis
    const redis = getRedisClient();
    const blacklisted = await redis.get(`blacklist:${token}`);
    if (blacklisted) {
      return res.status(401).json({ error: 'Token has been revoked.' });
    }

    // 4. Verify signature + expiry
    const payload = jwt.verify(token, process.env.JWT_SECRET);

    // 5. Load user from DB
    const user = await User.findById(payload.sub).select('-passwordHash -mfaSecret -refreshTokens');
    if (!user || !user.isActive || user.deletedAt) {
      return res.status(401).json({ error: 'User account not found or deactivated.' });
    }

    req.user  = user;
    req.token = token;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Access token expired.', code: 'TOKEN_EXPIRED' });
    }
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid access token.' });
    }
    next(err);
  }
}

/**
 * Role-based access guard.
 * Usage: authorize('admin')
 */
function authorize(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Not authenticated.' });
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions.' });
    }
    next();
  };
}

/**
 * Attach audit logging helper to req.
 */
function attachAudit(req, res, next) {
  req.audit = async (action, resource, meta = {}, success = true, error = null) => {
    await AuditLog.create({
      user:      req.user?._id,
      action,
      resource,
      metadata:  meta,
      ip:        req.ip,
      userAgent: req.headers['user-agent'],
      success,
      error,
    }).catch(() => {}); // never block on audit failure
  };
  next();
}

module.exports = { authenticate, authorize, attachAudit };
